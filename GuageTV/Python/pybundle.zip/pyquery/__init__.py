# -*- coding: utf-8 -*-
"""Pure-Python subset of ``pyquery`` for the GuageTV pybundle.

Built on the sibling ``lxml`` shim (the same dependency the real
pyquery has).  ``PyQuery`` covers the CSS subset spiders use:
``tag``, ``*``, ``.class``, ``#id``, ``tag.class``, descendant
(space) and child (``>``) combinators, ``[attr]``, ``[attr='v']``,
comma groups, and the structural ``:first`` / ``:last`` (real
pyquery translates them to first/last-child semantics — verified
against pyquery on lxml 6.x).  Methods: ``find``, ``filter``,
``eq``, ``items``, ``text``, ``html``, ``attr``, ``val``,
``children``, ``parent``, calling the instance to search within
the current set, ``len()``, iteration and indexing yielding the
underlying elements (``items()`` yields one-element PyQuery
wrappers, as in the real library).

Not supported: ``+``/``~`` combinators, attribute operators other
than ``=``, jQuery positional pseudos such as ``:eq()`` inside a
selector string (use the ``.eq()`` method), ``:nth-child`` and
friends other than ``:first-child``/``:last-child``, and the
mutation/traversal helpers outside the list above.
"""

import re

try:
    from lxml import etree as _etree
except Exception:  # pragma: no cover - bundle always ships both
    _etree = None

__all__ = ["PyQuery"]


# ---------------------------------------------------------------------------
# CSS subset
# ---------------------------------------------------------------------------

def _split_groups(selector):
    groups = []
    buf = []
    depth = 0
    quote = None
    for ch in selector:
        if quote:
            buf.append(ch)
            if ch == quote:
                quote = None
        elif ch in "\"'":
            quote = ch
            buf.append(ch)
        elif ch == "[":
            depth += 1
            buf.append(ch)
        elif ch == "]":
            depth -= 1
            buf.append(ch)
        elif ch == "," and depth == 0:
            groups.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    groups.append("".join(buf))
    return [g.strip() for g in groups if g.strip()]


def _tokenise_group(group):
    """One selector group -> [(combinator, compound-string)] where
    combinator is None for the first compound, else ' ' or '>'."""
    parts = []
    buf = []
    depth = 0
    quote = None
    pending = None  # combinator that precedes the next compound

    def flush():
        nonlocal pending
        text = "".join(buf).strip()
        del buf[:]
        if text:
            parts.append((pending if parts else None, text))
            pending = None

    for ch in group:
        if quote:
            buf.append(ch)
            if ch == quote:
                quote = None
        elif ch in "\"'":
            quote = ch
            buf.append(ch)
        elif ch == "[":
            depth += 1
            buf.append(ch)
        elif ch == "]":
            depth -= 1
            buf.append(ch)
        elif depth == 0 and ch == ">":
            flush()
            pending = ">"
        elif depth == 0 and ch.isspace():
            flush()
            if parts and pending is None:
                pending = " "
        else:
            buf.append(ch)
    flush()
    return parts


_ATTR_RE = re.compile(
    r"^([\w:.-]+)\s*(?:=\s*(?:\"([^\"]*)\"|'([^']*)'|([^\s\"']+)))?$")


def _parse_compound(text):
    comp = {"tag": None, "id": None, "classes": [], "attrs": [], "pseudos": []}
    i = 0
    m = re.match(r"\*|[a-zA-Z][\w-]*", text)
    if m:
        if m.group(0) != "*":
            comp["tag"] = m.group(0).lower()
        i = m.end()
    while i < len(text):
        ch = text[i]
        if ch == "#":
            m = re.match(r"[\w-]+", text[i + 1:])
            comp["id"] = m.group(0)
            i += 1 + m.end()
        elif ch == ".":
            m = re.match(r"[\w-]+", text[i + 1:])
            comp["classes"].append(m.group(0))
            i += 1 + m.end()
        elif ch == "[":
            j = text.index("]", i)
            inner = text[i + 1:j].strip()
            m = _ATTR_RE.match(inner)
            if not m:
                raise ValueError("unsupported attribute selector [%s]" % inner)
            value = m.group(2)
            if value is None:
                value = m.group(3)
            if value is None:
                value = m.group(4)
            comp["attrs"].append((m.group(1), value))
            i = j + 1
        elif ch == ":":
            m = re.match(r"[\w-]+(?:\([^)]*\))?", text[i + 1:])
            comp["pseudos"].append(m.group(0))
            i += 1 + m.end()
        else:
            raise ValueError("unsupported selector %r" % text)
    return comp


def _element_siblings(el):
    if el._parent is None:
        return [el]
    return el._parent._children


def _matches_compound(el, comp):
    if comp["tag"] is not None and el.tag != comp["tag"]:
        return False
    if comp["id"] is not None and el.attrib.get("id") != comp["id"]:
        return False
    if comp["classes"]:
        have = (el.attrib.get("class") or "").split()
        for cls in comp["classes"]:
            if cls not in have:
                return False
    for name, value in comp["attrs"]:
        if name not in el.attrib:
            return False
        if value is not None and el.attrib.get(name) != value:
            return False
    for pseudo in comp["pseudos"]:
        if pseudo in ("first", "first-child"):
            if _element_siblings(el)[0] is not el:
                return False
        elif pseudo in ("last", "last-child"):
            if _element_siblings(el)[-1] is not el:
                return False
        else:
            raise ValueError("unsupported pseudo-class :%s" % pseudo)
    return True


def _matches_chain(el, chain):
    """chain: [(combinator, compound)] left->right; el must match
    the rightmost compound, ancestors satisfy the rest."""
    if not _matches_compound(el, chain[-1][1]):
        return False
    current = el
    for idx in range(len(chain) - 1, 0, -1):
        combinator = chain[idx][0] or " "
        compound = chain[idx - 1][1]
        if combinator == ">":
            parent = current._parent
            if parent is None or not _matches_compound(parent, compound):
                return False
            current = parent
        else:
            node = current._parent
            found = None
            while node is not None:
                if _matches_compound(node, compound):
                    found = node
                    break
                node = node._parent
            if found is None:
                return False
            current = found
    return True


def _compile(selector):
    chains = []
    for group in _split_groups(selector):
        chain = [(comb, _parse_compound(text))
                 for comb, text in _tokenise_group(group)]
        if chain:
            chains.append(chain)
    if not chains:
        raise ValueError("empty selector")
    return chains


# ---------------------------------------------------------------------------
# PyQuery
# ---------------------------------------------------------------------------

_WHITESPACE = re.compile(r"\s+")


def _squash(text):
    return _WHITESPACE.sub(" ", text).strip()


class PyQuery:
    def __init__(self, *args, **kwargs):
        if _etree is None:
            raise ImportError("pyquery shim needs the lxml shim alongside it")
        self.elements = []
        if args:
            arg = args[0]
            if isinstance(arg, PyQuery):
                self.elements = list(arg.elements)
            elif isinstance(arg, _etree.Element):
                self.elements = [arg]
            elif isinstance(arg, (list, tuple)):
                self.elements = [el for el in arg
                                 if isinstance(el, _etree.Element)]
            elif isinstance(arg, str):
                root = _etree.HTML(arg)
                self.elements = [root] if root is not None else []
            elif arg is None:
                self.elements = []
            else:
                raise TypeError("cannot build PyQuery from %r" % type(arg))
        elif "url" in kwargs:
            self.elements = self._from_url(kwargs["url"])
        elif "filename" in kwargs:
            with open(kwargs["filename"], "rb") as fh:
                root = _etree.HTML(fh.read())
            self.elements = [root] if root is not None else []

    @staticmethod
    def _from_url(url):
        try:
            import requests
        except ImportError:
            raise RuntimeError("pq(url=...) needs requests in the bundle")
        resp = requests.get(url, timeout=15)
        root = _etree.HTML(resp.text)
        return [root] if root is not None else []

    # -- selection ----------------------------------------------------
    def __call__(self, selector):
        return self.find(selector)

    def find(self, selector):
        chains = _compile(selector)
        out = []
        seen = set()
        for ctx in self.elements:
            for node in ctx.iter():
                if node is ctx:
                    continue
                if any(_matches_chain(node, chain) for chain in chains):
                    if id(node) not in seen:
                        seen.add(id(node))
                        out.append(node)
        result = PyQuery()
        result.elements = out
        return result

    def filter(self, selector):
        chains = _compile(selector)
        result = PyQuery()
        result.elements = [el for el in self.elements
                           if any(_matches_chain(el, chain) for chain in chains)]
        return result

    def eq(self, index):
        result = PyQuery()
        if -len(self.elements) <= index < len(self.elements):
            result.elements = [self.elements[index]]
        return result

    def items(self):
        for el in self.elements:
            single = PyQuery()
            single.elements = [el]
            yield single

    def children(self, selector=None):
        out = []
        for el in self.elements:
            out.extend(el._children)
        result = PyQuery()
        result.elements = out
        if selector:
            result = result.filter(selector)
        return result

    def parent(self, selector=None):
        out = []
        seen = set()
        for el in self.elements:
            parent = el._parent
            if parent is not None and id(parent) not in seen:
                seen.add(id(parent))
                out.append(parent)
        result = PyQuery()
        result.elements = out
        if selector:
            result = result.filter(selector)
        return result

    # -- content --------------------------------------------------------
    def text(self):
        return " ".join(_squash(el.text_content()) for el in self.elements)

    def html(self):
        if not self.elements:
            return None
        el = self.elements[0]
        parts = []
        if el.text:
            parts.append(_etree._esc_text(el.text))
        for child in el._children:
            # tostring includes the child's tail by default, which
            # is exactly what inner HTML needs.
            parts.append(_etree.tostring(child, encoding="unicode"))
        return "".join(parts)

    def attr(self, name, value=None):
        if isinstance(name, dict):
            for key, val in name.items():
                for el in self.elements:
                    el.set(key, val)
            return self
        if value is not None:
            for el in self.elements:
                el.set(name, value)
            return self
        if not self.elements:
            return None
        return self.elements[0].attrib.get(name)

    def val(self):
        if not self.elements:
            return None
        el = self.elements[0]
        if el.tag == "textarea":
            return el.text or ""
        return el.attrib.get("value")

    # -- container protocol ----------------------------------------------
    def __len__(self):
        return len(self.elements)

    def __iter__(self):
        return iter(self.elements)

    def __getitem__(self, index):
        if isinstance(index, slice):
            result = PyQuery()
            result.elements = self.elements[index]
            return result
        return self.elements[index]

    def __repr__(self):
        return "<PyQuery %r>" % (self.elements,)
