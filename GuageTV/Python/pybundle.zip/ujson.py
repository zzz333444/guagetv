# ujson shim over the stdlib json module — spiders import ujson
# purely for speed; the API surface they touch is dumps/loads.
import json as _json

JSONDecodeError = _json.JSONDecodeError
JSONEncoder = _json.JSONEncoder
JSONDecoder = _json.JSONDecoder


def dumps(obj, **kwargs):
    kwargs.setdefault("ensure_ascii", False)
    return _json.dumps(obj, **kwargs)


def loads(s, **kwargs):
    return _json.loads(s, **kwargs)


def dump(obj, fp, **kwargs):
    kwargs.setdefault("ensure_ascii", False)
    return _json.dump(obj, fp, **kwargs)


def load(fp, **kwargs):
    return _json.load(fp, **kwargs)


encode = dumps
decode = loads
