# Pure-Python RSA, API-compatible with the subset of PyCryptodome's
# Crypto.PublicKey.RSA that TVBox spiders actually use:
#   generate(bits), construct((n, e[, d, p, q])), import_key(pem/der),
#   key.export_key(), key.public_key(), key.has_private(),
#   key.size_in_bits()/size_in_bytes()
# DER encode/decode is implemented here (no external deps); the random
# source is Crypto.Random when available, else os.urandom. Key
# generation uses trial division + Miller-Rabin and is meant for
# interoperability/testing, not for production key custody.

import base64
import math
import os

try:
    from Crypto.Random import get_random_bytes as _rand_bytes
except Exception:  # pragma: no cover - bundle always ships it
    def _rand_bytes(n):
        return os.urandom(n)


_RSA_OID = (1, 2, 840, 113549, 1, 1, 1)


# ---------------------------------------------------------------- DER

def _der_length(n):
    if n < 0x80:
        return bytes([n])
    raw = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(raw)]) + raw


def _der_tlv(tag, content):
    return bytes([tag]) + _der_length(len(content)) + content


def _der_integer(value):
    if value < 0:
        raise ValueError("Only non-negative INTEGERs are supported")
    raw = value.to_bytes(max(1, (value.bit_length() + 7) // 8), "big")
    if raw[0] & 0x80:
        raw = b"\x00" + raw
    return _der_tlv(0x02, raw)


def _der_sequence(*items):
    return _der_tlv(0x30, b"".join(items))


def _der_oid(oid):
    first = 40 * oid[0] + oid[1]
    body = bytearray([first])
    for value in oid[2:]:
        chunk = [value & 0x7F]
        value >>= 7
        while value:
            chunk.append(0x80 | (value & 0x7F))
            value >>= 7
        body.extend(reversed(chunk))
    return _der_tlv(0x06, bytes(body))


def _der_null():
    return b"\x05\x00"


def _der_octet_string(data):
    return _der_tlv(0x04, data)


def _der_bit_string(data):
    return _der_tlv(0x03, b"\x00" + data)


def _alg_id():
    return _der_sequence(_der_oid(_RSA_OID), _der_null())


class _DerReader:
    def __init__(self, data):
        self.data = data
        self.pos = 0

    def read_tlv(self):
        if self.pos >= len(self.data):
            raise ValueError("Unexpected end of DER data")
        tag = self.data[self.pos]
        self.pos += 1
        if self.pos >= len(self.data):
            raise ValueError("Truncated DER length")
        first = self.data[self.pos]
        self.pos += 1
        if first & 0x80:
            count = first & 0x7F
            if count == 0 or self.pos + count > len(self.data):
                raise ValueError("Invalid DER length")
            length = int.from_bytes(self.data[self.pos:self.pos + count],
                                    "big")
            self.pos += count
        else:
            length = first
        if self.pos + length > len(self.data):
            raise ValueError("DER content overruns buffer")
        content = self.data[self.pos:self.pos + length]
        self.pos += length
        return tag, content

    def expect(self, tag):
        actual, content = self.read_tlv()
        if actual != tag:
            raise ValueError("DER tag mismatch: expected %#x, got %#x"
                             % (tag, actual))
        return content

    def read_sequence(self):
        return _DerReader(self.expect(0x30))

    def read_integer(self):
        content = self.expect(0x02)
        if not content:
            raise ValueError("Empty DER INTEGER")
        return int.from_bytes(content, "big")

    def read_oid(self):
        content = self.expect(0x06)
        if not content:
            raise ValueError("Empty DER OID")
        values = [content[0] // 40, content[0] % 40]
        acc = 0
        for byte in content[1:]:
            acc = (acc << 7) | (byte & 0x7F)
            if not byte & 0x80:
                values.append(acc)
                acc = 0
        return tuple(values)

    def at_end(self):
        return self.pos >= len(self.data)


def _read_alg_id(reader):
    seq = reader.read_sequence()
    oid = seq.read_oid()
    if oid != _RSA_OID:
        raise ValueError("Not an RSA key (OID %s)" % (oid,))
    # NULL parameters (or none) follow; ignore them.


# ------------------------------------------------------------- primes

def _small_primes(limit=1000):
    sieve = [True] * (limit + 1)
    sieve[0:2] = [False, False]
    for i in range(2, int(limit ** 0.5) + 1):
        if sieve[i]:
            sieve[i * i::i] = [False] * len(sieve[i * i::i])
    return [i for i, is_p in enumerate(sieve) if is_p]


_SMALL_PRIMES = _small_primes()


def _rand_below(bound, randfunc):
    nbytes = (bound.bit_length() + 7) // 8
    while True:
        value = int.from_bytes(randfunc(nbytes), "big")
        if value < bound:
            return value


def _is_probable_prime(n, randfunc, rounds=16):
    if n < 2:
        return False
    for p in _SMALL_PRIMES:
        if n % p == 0:
            return n == p
    d = n - 1
    s = 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for _ in range(rounds):
        a = _rand_below(n - 3, randfunc) + 2
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def _gen_prime(bits, e, randfunc):
    nbytes = (bits + 7) // 8
    while True:
        raw = bytearray(randfunc(nbytes))
        excess = len(raw) * 8 - bits
        raw[0] &= 0xFF >> excess
        # Set the top two bits so the product of two such primes has
        # the full target size, and the low bit (odd candidate).
        raw[0] |= (0xC0 >> excess) & 0xFF
        raw[-1] |= 1
        candidate = int.from_bytes(bytes(raw), "big")
        if math.gcd(candidate - 1, e) != 1:
            continue
        if _is_probable_prime(candidate, randfunc):
            return candidate


def _factor_from_ed(n, e, d, randfunc):
    """Recover (p, q) from (n, e, d) — the standard algorithm used
    when a key is constructed from the private exponent alone."""
    k = e * d - 1
    if k <= 0 or k % 2 != 0:
        return None
    t = k
    s = 0
    while t % 2 == 0:
        t //= 2
        s += 1
    for _ in range(100):
        g = _rand_below(n - 3, randfunc) + 2
        x = pow(g, t, n)
        if x in (1, n - 1):
            continue
        for _ in range(s):
            y = pow(x, 2, n)
            if y == 1:
                factor = math.gcd(x - 1, n)
                if 1 < factor < n and n % factor == 0:
                    return factor, n // factor
                break
            if y == n - 1:
                break
            x = y
    return None


# ---------------------------------------------------------------- key

class RsaKey:
    def __init__(self, n, e, d=None, p=None, q=None, u=None):
        self._n = int(n)
        self._e = int(e)
        self._d = int(d) if d is not None else None
        self._p = int(p) if p is not None else None
        self._q = int(q) if q is not None else None
        if self._p is not None and self._q is not None:
            if self._p * self._q != self._n:
                raise ValueError("p*q != n")
            # Order is preserved as imported/constructed (PyCryptodome
            # does not normalise p > q; the CRT coefficient below is
            # computed for whichever order the key carries).
        # CRT coefficient: q^{-1} mod p (PKCS#1 qInv)
        if u is not None:
            self._u = int(u)
        elif self._p is not None:
            self._u = pow(self._q, -1, self._p)
        else:
            self._u = None

    # -- attributes --------------------------------------------------
    @property
    def n(self):
        return self._n

    @property
    def e(self):
        return self._e

    @property
    def d(self):
        return self._d

    @property
    def p(self):
        return self._p

    @property
    def q(self):
        return self._q

    @property
    def u(self):
        return self._u

    def has_private(self):
        return self._d is not None

    def public_key(self):
        return RsaKey(self._n, self._e)

    publickey = public_key

    def size_in_bits(self):
        return self._n.bit_length()

    def size_in_bytes(self):
        return (self.size_in_bits() + 7) // 8

    # -- raw operations ----------------------------------------------
    def _encrypt(self, m):
        if not 0 <= m < self._n:
            raise ValueError("Message representative out of range")
        return pow(m, self._e, self._n)

    def _decrypt(self, c):
        if not self.has_private():
            raise TypeError("This is not a private key")
        if not 0 <= c < self._n:
            raise ValueError("Ciphertext representative out of range")
        if self._p is not None and self._q is not None:
            dp = self._d % (self._p - 1)
            dq = self._d % (self._q - 1)
            mp = pow(c, dp, self._p)
            mq = pow(c, dq, self._q)
            h = (self._u * (mp - mq)) % self._p
            return mq + h * self._q
        return pow(c, self._d, self._n)

    # -- export --------------------------------------------------------
    def _pkcs1_private_der(self):
        if not self.has_private():
            raise TypeError("This is not a private key")
        if self._p is None or self._q is None:
            raise ValueError("PKCS#1 export needs p and q")
        dp = self._d % (self._p - 1)
        dq = self._d % (self._q - 1)
        return _der_sequence(
            _der_integer(0), _der_integer(self._n), _der_integer(self._e),
            _der_integer(self._d), _der_integer(self._p),
            _der_integer(self._q), _der_integer(dp), _der_integer(dq),
            _der_integer(self._u))

    def _pkcs1_public_der(self):
        return _der_sequence(_der_integer(self._n), _der_integer(self._e))

    def _spki_der(self):
        return _der_sequence(_alg_id(),
                             _der_bit_string(self._pkcs1_public_der()))

    def export_key(self, format="PEM", pkcs=None, passphrase=None,
                   protection=None, randfunc=None, prot_params=None):
        if passphrase is not None or protection is not None:
            raise ValueError("Encrypted key export is not supported "
                             "by the pure-Python shim")
        if format not in ("PEM", "DER"):
            raise ValueError("format must be 'PEM' or 'DER'")
        if self.has_private():
            if pkcs == 8:
                der = _der_sequence(
                    _der_integer(0), _alg_id(),
                    _der_octet_string(self._pkcs1_private_der()))
                label = "PRIVATE KEY"
            else:
                der = self._pkcs1_private_der()
                label = "RSA PRIVATE KEY"
        else:
            if pkcs == 1:
                der = self._pkcs1_public_der()
                label = "RSA PUBLIC KEY"
            else:
                der = self._spki_der()
                label = "PUBLIC KEY"
        if format == "DER":
            return der
        b64 = base64.b64encode(der).decode("ascii")
        lines = [b64[i:i + 64] for i in range(0, len(b64), 64)]
        pem = "-----BEGIN %s-----\n%s\n-----END %s-----\n" % (
            label, "\n".join(lines), label)
        return pem.encode("ascii")

    # PyCryptodome spelling used by some spiders
    exportKey = export_key

    def __eq__(self, other):
        if not isinstance(other, RsaKey):
            return NotImplemented
        return (self._n == other._n and self._e == other._e
                and self._d == other._d)

    def __ne__(self, other):
        eq = self.__eq__(other)
        return eq if eq is NotImplemented else not eq

    def __repr__(self):
        kind = "Private" if self.has_private() else "Public"
        return "RsaKey(%s, n=%d bits)" % (kind, self.size_in_bits())


# ------------------------------------------------------------- import

def _key_from_pkcs1_private(reader):
    version = reader.read_integer()
    if version not in (0, 1):
        raise ValueError("Unsupported PKCS#1 version %d" % version)
    n = reader.read_integer()
    e = reader.read_integer()
    d = reader.read_integer()
    p = reader.read_integer()
    q = reader.read_integer()
    reader.read_integer()  # dP
    reader.read_integer()  # dQ
    u = reader.read_integer()
    return RsaKey(n, e, d=d, p=p, q=q, u=u)


def _key_from_pkcs1_public(reader):
    n = reader.read_integer()
    e = reader.read_integer()
    return RsaKey(n, e)


def _import_der(der):
    reader = _DerReader(der)
    top = reader.read_sequence()
    # Peek at the structure: the second element decides the format.
    first = top.read_tlv()
    if first[0] == 0x30:
        # AlgorithmIdentifier first?? Not a known layout.
        raise ValueError("Unsupported DER key structure")
    second_tag, second_content = top.read_tlv()
    if second_tag == 0x30:
        # PKCS#8 (int, algId, octet) or SPKI (algId...) — SPKI has the
        # algId as FIRST element, so here it must be PKCS#8.
        version = int.from_bytes(first[1], "big")
        if version != 0:
            raise ValueError("Unsupported PKCS#8 version")
        _read_alg_id(_DerReader(_der_tlv(0x30, second_content)))
        octet_tag, octet = top.read_tlv()
        if octet_tag != 0x04:
            raise ValueError("PKCS#8 payload is not an octet string")
        inner = _DerReader(octet).read_sequence()
        return _key_from_pkcs1_private(inner)
    if second_tag == 0x03:
        # SubjectPublicKeyInfo: first element was the algId sequence,
        # but we already consumed it as a raw TLV with tag 0x30 — this
        # branch is unreachable given the check above; kept for safety.
        raise ValueError("Unsupported DER key structure")
    if first[0] != 0x02:
        raise ValueError("Unsupported DER key structure")
    # first is an INTEGER; second too.
    second_value = int.from_bytes(second_content, "big")
    if not top.at_end():
        third_tag, _ = top.read_tlv()
        if third_tag == 0x02:
            # PKCS#1 private: version, n, e, d, ...
            full = _DerReader(der).read_sequence()
            return _key_from_pkcs1_private(full)
    # Only two integers -> PKCS#1 public (version-less): the first was n.
    n = int.from_bytes(first[1], "big")
    return RsaKey(n, second_value)


def _import_pem(pem_bytes):
    text = pem_bytes.decode("ascii", errors="strict")
    label = None
    body_lines = []
    in_body = False
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("-----BEGIN ") and line.endswith("-----"):
            label = line[11:-5].strip()
            in_body = True
            continue
        if line.startswith("-----END "):
            break
        if in_body:
            if ":" in line:  # PEM headers (Proc-Type, DEK-Info, ...)
                if "ENCRYPTED" in line.upper():
                    raise ValueError("Encrypted PEM keys are not "
                                     "supported by the pure-Python shim")
                continue
            body_lines.append(line)
    if label is None:
        raise ValueError("Not a PEM file")
    der = base64.b64decode("".join(body_lines))
    if label == "RSA PRIVATE KEY":
        return _key_from_pkcs1_private(_DerReader(der).read_sequence())
    if label == "RSA PUBLIC KEY":
        return _key_from_pkcs1_public(_DerReader(der).read_sequence())
    if label == "PUBLIC KEY":
        top = _DerReader(der).read_sequence()
        _read_alg_id(top)
        tag, bit_string = top.read_tlv()
        if tag != 0x03 or not bit_string or bit_string[0] != 0:
            raise ValueError("Malformed subjectPublicKeyInfo")
        inner = _DerReader(bit_string[1:]).read_sequence()
        return _key_from_pkcs1_public(inner)
    if label == "PRIVATE KEY":
        top = _DerReader(der).read_sequence()
        version = top.read_integer()
        if version != 0:
            raise ValueError("Unsupported PKCS#8 version")
        _read_alg_id(top)
        tag, octet = top.read_tlv()
        if tag != 0x04:
            raise ValueError("PKCS#8 payload is not an octet string")
        inner = _DerReader(octet).read_sequence()
        return _key_from_pkcs1_private(inner)
    if label == "ENCRYPTED PRIVATE KEY":
        raise ValueError("Encrypted keys are not supported by the "
                         "pure-Python shim")
    raise ValueError("Unsupported PEM label %r" % label)


def import_key(extern_key, passphrase=None):
    if passphrase is not None:
        raise ValueError("Encrypted keys are not supported by the "
                         "pure-Python shim")
    if isinstance(extern_key, str):
        extern_key = extern_key.encode("ascii")
    extern_key = bytes(extern_key)
    if b"-----BEGIN" in extern_key:
        return _import_pem(extern_key)
    # Raw DER: try the labeled layouts structurally.
    try:
        return _import_der(der=extern_key)
    except Exception:
        pass
    # SPKI in DER has the algId sequence as first element, which
    # _import_der refuses; retry through the PEM-label logic shape.
    top = _DerReader(extern_key).read_sequence()
    first_tag, _ = top.read_tlv()
    if first_tag == 0x30:
        top2 = _DerReader(extern_key).read_sequence()
        _read_alg_id(top2)
        tag, bit_string = top2.read_tlv()
        if tag == 0x03 and bit_string and bit_string[0] == 0:
            inner = _DerReader(bit_string[1:]).read_sequence()
            return _key_from_pkcs1_public(inner)
    raise ValueError("Cannot import this key")


importKey = import_key


# ------------------------------------------------------------ factory

def construct(components, consistency_check=True):
    if len(components) == 2:
        n, e = components
        return RsaKey(n, e)
    if len(components) == 3:
        n, e, d = components
        key = RsaKey(n, e, d=d)
        if consistency_check:
            found = _factor_from_ed(int(n), int(e), int(d), _rand_bytes)
            if found:
                p, q = found
                return RsaKey(n, e, d=d, p=p, q=q)
        return key
    if len(components) in (5, 6):
        n, e, d, p, q = components[:5]
        u = components[5] if len(components) == 6 else None
        return RsaKey(n, e, d=d, p=p, q=q, u=u)
    raise ValueError("RSA key components must be a tuple of 2, 3, 5 "
                     "or 6 integers")


def generate(bits, randfunc=None, progress_func=None, e=65537):
    if bits < 512:
        raise ValueError("RSA modulus is too short")
    if e % 2 == 0 or e < 3:
        raise ValueError("RSA public exponent must be odd and >= 3")
    randfunc = randfunc or _rand_bytes
    p_bits = bits // 2
    q_bits = bits - p_bits
    while True:
        p = _gen_prime(p_bits, e, randfunc)
        q = _gen_prime(q_bits, e, randfunc)
        if p == q:
            continue
        n = p * q
        if n.bit_length() != bits:
            continue
        phi = (p - 1) * (q - 1)
        if math.gcd(e, phi) != 1:
            continue
        d = pow(e, -1, phi)
        return RsaKey(n, e, d=d, p=p, q=q)
