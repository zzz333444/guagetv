# Pure-Python RSASSA-PSS (EMSA-PSS + MGF1), API-compatible with the
# subset of PyCryptodome's Crypto.Signature.pss that TVBox spiders
# use: new(key[, salt_bytes][, rand_func]).sign(hash_obj) /
# .verify(hash_obj, signature). The hash object only needs digest()
# and digest_size, plus a way to hash fresh data (its .new() method,
# or a hashlib-style .name); both the bundle's Crypto.Hash shims and
# hashlib objects qualify.

import hashlib
import hmac as _hmac
import os

try:
    from Crypto.Random import get_random_bytes as _rand_bytes
except Exception:  # pragma: no cover
    def _rand_bytes(n):
        return os.urandom(n)


def _hash_factory(hash_obj):
    new_method = getattr(hash_obj, "new", None)
    if callable(new_method):
        return lambda data=b"": new_method(data)
    name = getattr(hash_obj, "name", None)
    if isinstance(name, str):
        alg = name.lower().replace("-", "")
        return lambda data=b"": hashlib.new(alg, data)
    cls = type(hash_obj)
    return lambda data=b"": cls(data)


def MGF1(seed, mask_len, hash_obj):
    factory = _hash_factory(hash_obj)
    h_len = hash_obj.digest_size
    out = bytearray()
    counter = 0
    while len(out) < mask_len:
        c = counter.to_bytes(4, "big")
        out += factory(seed + c).digest()
        counter += 1
    return bytes(out[:mask_len])


def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))


class _PSSSignature:
    def __init__(self, key, mask_func=None, salt_bytes=None, rand_func=None):
        self._key = key
        self._mask_func = mask_func
        self._salt_bytes = salt_bytes
        self._rand_func = rand_func or _rand_bytes

    def can_sign(self):
        return self._key.has_private()

    def _mgf(self, seed, mask_len, hash_obj):
        if self._mask_func is not None:
            return self._mask_func(seed, mask_len)
        return MGF1(seed, mask_len, hash_obj)

    def sign(self, hash_obj):
        if not self._key.has_private():
            raise TypeError("This is not a private key")
        mod_bits = self._key.size_in_bits()
        em_len = (mod_bits - 1 + 7) // 8
        h_len = hash_obj.digest_size
        if self._salt_bytes is not None:
            salt_len = self._salt_bytes
        else:
            # PyCryptodome's default when salt_bytes is not given —
            # on BOTH sign and verify — is the digest size, not the
            # RFC maximum. Matching it keeps pss.new(key) callers
            # cross-compatible in both directions. (This shim's
            # verify still recovers any salt length from the EM.)
            salt_len = h_len
        if em_len < h_len + salt_len + 2:
            raise ValueError("Key too small for PSS with this hash/salt")
        salt = self._rand_func(salt_len) if salt_len else b""
        m_hash = hash_obj.digest()
        factory = _hash_factory(hash_obj)
        h = factory(b"\x00" * 8 + m_hash + salt).digest()
        ps = b"\x00" * (em_len - salt_len - h_len - 2)
        db = ps + b"\x01" + salt
        db_mask = self._mgf(h, em_len - h_len - 1, hash_obj)
        masked = bytearray(_xor(db, db_mask))
        excess = 8 * em_len - (mod_bits - 1)
        masked[0] &= 0xFF >> excess
        em = bytes(masked) + h + b"\xbc"
        s = self._key._decrypt(int.from_bytes(em, "big"))
        return s.to_bytes(self._key.size_in_bytes(), "big")

    def verify(self, hash_obj, signature):
        k = self._key.size_in_bytes()
        if len(signature) != k:
            raise ValueError("Invalid signature")
        s = int.from_bytes(signature, "big")
        if s >= self._key.n:
            raise ValueError("Invalid signature")
        mod_bits = self._key.size_in_bits()
        em_len = (mod_bits - 1 + 7) // 8
        em = self._key._encrypt(s).to_bytes(em_len, "big")
        h_len = hash_obj.digest_size
        if em_len < h_len + 2 or em[-1:] != b"\xbc":
            raise ValueError("Invalid signature")
        masked = em[:em_len - h_len - 1]
        h = em[em_len - h_len - 1:em_len - 1]
        excess = 8 * em_len - (mod_bits - 1)
        if masked[0] & ((0xFF << (8 - excess)) & 0xFF):
            raise ValueError("Invalid signature")
        db_mask = self._mgf(h, em_len - h_len - 1, hash_obj)
        db = bytearray(_xor(masked, db_mask))
        db[0] &= 0xFF >> excess
        # DB = PS (zero bytes) || 0x01 || salt
        i = 0
        while i < len(db) and db[i] == 0:
            i += 1
        if i >= len(db) or db[i] != 0x01:
            raise ValueError("Invalid signature")
        salt = bytes(db[i + 1:])
        m_hash = hash_obj.digest()
        factory = _hash_factory(hash_obj)
        expected_h = factory(b"\x00" * 8 + m_hash + salt).digest()
        if not _hmac.compare_digest(h, expected_h):
            raise ValueError("Invalid signature")


def new(key, mask_func=None, salt_bytes=None, rand_func=None):
    return _PSSSignature(key, mask_func=mask_func,
                         salt_bytes=salt_bytes, rand_func=rand_func)
