# Pure-Python RSASSA-PKCS1-v1_5, API-compatible with the subset of
# PyCryptodome's Crypto.Signature.pkcs1_15 that TVBox spiders use:
# new(key).sign(hash_obj) / .verify(hash_obj, signature).
#
# The hash object only needs digest() and digest_size (plus oid or a
# hashlib-style name when available); the DigestInfo prefix is built
# here, so both the bundle's Crypto.Hash shims and hashlib objects
# work.

import hmac as _hmac

_OID_BY_NAME = {
    "md5": (1, 2, 840, 113549, 2, 5),
    "sha1": (1, 3, 14, 3, 2, 26),
    "sha224": (2, 16, 840, 1, 101, 3, 4, 2, 4),
    "sha256": (2, 16, 840, 1, 101, 3, 4, 2, 1),
    "sha384": (2, 16, 840, 1, 101, 3, 4, 2, 2),
    "sha512": (2, 16, 840, 1, 101, 3, 4, 2, 3),
    "sha512224": (2, 16, 840, 1, 101, 3, 4, 2, 5),
    "sha512256": (2, 16, 840, 1, 101, 3, 4, 2, 6),
}

_OID_BY_SIZE = {
    16: _OID_BY_NAME["md5"],
    20: _OID_BY_NAME["sha1"],
    28: _OID_BY_NAME["sha224"],
    32: _OID_BY_NAME["sha256"],
    48: _OID_BY_NAME["sha384"],
    64: _OID_BY_NAME["sha512"],
}


def _oid_tuple(oid):
    if isinstance(oid, (tuple, list)):
        return tuple(oid)
    return tuple(int(x) for x in str(oid).split("."))


def _der_length(n):
    if n < 0x80:
        return bytes([n])
    raw = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(raw)]) + raw


def _der_tlv(tag, content):
    return bytes([tag]) + _der_length(len(content)) + content


def _der_oid(oid):
    body = bytearray([40 * oid[0] + oid[1]])
    for value in oid[2:]:
        chunk = [value & 0x7F]
        value >>= 7
        while value:
            chunk.append(0x80 | (value & 0x7F))
            value >>= 7
        body.extend(reversed(chunk))
    return _der_tlv(0x06, bytes(body))


def _digest_info(hash_obj):
    digest = hash_obj.digest()
    oid = getattr(hash_obj, "oid", None)
    if oid is None:
        name = getattr(hash_obj, "name", None)
        if isinstance(name, str):
            oid = _OID_BY_NAME.get(name.lower().replace("-", ""))
    if oid is None:
        size = getattr(hash_obj, "digest_size", len(digest))
        oid = _OID_BY_SIZE.get(size)
    if oid is None:
        raise ValueError("Unsupported hash algorithm for PKCS#1 v1.5")
    alg_id = _der_tlv(0x30, _der_oid(_oid_tuple(oid)) + b"\x05\x00")
    return _der_tlv(0x30, alg_id + _der_tlv(0x04, digest))


def _emsa_encode(hash_obj, em_len):
    t = _digest_info(hash_obj)
    if em_len < len(t) + 11:
        raise ValueError("Intended encoded message length too short")
    ps = b"\xff" * (em_len - len(t) - 3)
    return b"\x00\x01" + ps + b"\x00" + t


class _PKCS115Signature:
    def __init__(self, key):
        self._key = key

    def can_sign(self):
        return self._key.has_private()

    def sign(self, hash_obj):
        if not self._key.has_private():
            raise TypeError("This is not a private key")
        k = self._key.size_in_bytes()
        em = _emsa_encode(hash_obj, k)
        s = self._key._decrypt(int.from_bytes(em, "big"))
        return s.to_bytes(k, "big")

    def verify(self, hash_obj, signature):
        k = self._key.size_in_bytes()
        if len(signature) != k:
            raise ValueError("Invalid signature")
        s = int.from_bytes(signature, "big")
        if s >= self._key.n:
            raise ValueError("Invalid signature")
        em = self._key._encrypt(s).to_bytes(k, "big")
        expected = _emsa_encode(hash_obj, k)
        if not _hmac.compare_digest(em, expected):
            raise ValueError("Invalid signature")


def new(key):
    return _PKCS115Signature(key)
