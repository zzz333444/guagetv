from Crypto.Hash._hashlib_shim import _make
_SHA512 = _make("sha512")
new = _SHA512.new
digest_size = _SHA512(b"").digest_size
block_size = _SHA512(b"").block_size
