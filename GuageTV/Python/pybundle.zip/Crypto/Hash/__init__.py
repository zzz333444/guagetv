# Subset of PyCryptodome's Crypto.Hash, backed by hashlib.
