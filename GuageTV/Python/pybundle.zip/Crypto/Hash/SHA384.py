from Crypto.Hash._hashlib_shim import _make
_SHA384 = _make("sha384")
new = _SHA384.new
digest_size = _SHA384(b"").digest_size
block_size = _SHA384(b"").block_size
