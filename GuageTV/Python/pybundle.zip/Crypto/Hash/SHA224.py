from Crypto.Hash._hashlib_shim import _make
_SHA224 = _make("sha224")
new = _SHA224.new
digest_size = _SHA224(b"").digest_size
block_size = _SHA224(b"").block_size
