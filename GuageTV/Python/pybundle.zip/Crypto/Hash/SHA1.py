from Crypto.Hash._hashlib_shim import _make
_SHA1 = _make("sha1")
new = _SHA1.new
digest_size = _SHA1(b"").digest_size
block_size = _SHA1(b"").block_size
