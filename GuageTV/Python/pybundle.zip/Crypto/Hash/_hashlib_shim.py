# Hash factory backed by hashlib, API-compatible with the subset of
# PyCryptodome's Crypto.Hash modules that TVBox spiders use.
import hashlib


def _make(name):
    class _Hash:
        def __init__(self, data=b""):
            self._h = hashlib.new(name)
            if data:
                self._h.update(data)
            self.digest_size = self._h.digest_size
            self.block_size = self._h.block_size

        def update(self, data):
            self._h.update(data)
            return self

        def digest(self):
            return self._h.digest()

        def hexdigest(self):
            return self._h.hexdigest()

        def copy(self):
            other = _Hash.__new__(_Hash)
            other._h = self._h.copy()
            other.digest_size = self.digest_size
            other.block_size = self.block_size
            return other

        @classmethod
        def new(cls, data=b""):
            return cls(data)

    _Hash.__name__ = name.upper().replace("-", "")
    return _Hash


def module(name):
    return _make(name)
