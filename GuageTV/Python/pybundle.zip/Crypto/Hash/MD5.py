from Crypto.Hash._hashlib_shim import _make
_MD5 = _make("md5")
new = _MD5.new
digest_size = _MD5(b"").digest_size
block_size = _MD5(b"").block_size
