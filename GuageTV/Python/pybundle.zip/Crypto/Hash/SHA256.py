from Crypto.Hash._hashlib_shim import _make
_SHA256 = _make("sha256")
new = _SHA256.new
digest_size = _SHA256(b"").digest_size
block_size = _SHA256(b"").block_size
