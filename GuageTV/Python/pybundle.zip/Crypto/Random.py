# Subset of PyCryptodome's Crypto.Random, backed by os.urandom.
import os


def get_random_bytes(n):
    return os.urandom(n)


class _Random:
    def read(self, n):
        return os.urandom(n)


def new():
    return _Random()
