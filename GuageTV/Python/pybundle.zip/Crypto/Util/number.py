# Subset of PyCryptodome's Crypto.Util.number.


def bytes_to_long(s):
    return int.from_bytes(s, "big")


def long_to_bytes(n, blocksize=0):
    if n < 0:
        raise ValueError("n must be >= 0")
    out = n.to_bytes(max(1, (n.bit_length() + 7) // 8), "big")
    if blocksize and len(out) < blocksize:
        out = bytes(blocksize - len(out)) + out
    return out


def size(n):
    return n.bit_length()
