# Padding helpers, API-compatible with PyCryptodome's Crypto.Util.Padding.


def pad(data_to_pad, block_size, style="pkcs7"):
    if style == "pkcs7":
        padding_len = block_size - len(data_to_pad) % block_size
        return data_to_pad + bytes([padding_len]) * padding_len
    if style == "x923":
        padding_len = block_size - len(data_to_pad) % block_size
        return data_to_pad + b"\x00" * (padding_len - 1) + bytes([padding_len])
    if style == "iso7816":
        padding_len = block_size - len(data_to_pad) % block_size
        return data_to_pad + b"\x80" + b"\x00" * (padding_len - 1)
    raise ValueError("Unknown padding style")


def unpad(padded_data, block_size, style="pkcs7"):
    if not padded_data or len(padded_data) % block_size:
        raise ValueError("Input data is not padded")
    if style == "pkcs7":
        padding_len = padded_data[-1]
        if padding_len < 1 or padding_len > block_size:
            raise ValueError("Padding is incorrect")
        if padded_data[-padding_len:] != bytes([padding_len]) * padding_len:
            raise ValueError("PKCS#7 padding is incorrect")
        return padded_data[:-padding_len]
    if style == "x923":
        padding_len = padded_data[-1]
        if padding_len < 1 or padding_len > block_size:
            raise ValueError("Padding is incorrect")
        if padded_data[-padding_len:-1] != b"\x00" * (padding_len - 1):
            raise ValueError("Padding is incorrect")
        return padded_data[:-padding_len]
    if style == "iso7816":
        idx = len(padded_data) - 1
        while idx >= 0 and padded_data[idx] == 0:
            idx -= 1
        if idx < 0 or padded_data[idx] != 0x80:
            raise ValueError("Padding is incorrect")
        return padded_data[:idx]
    raise ValueError("Unknown padding style")
