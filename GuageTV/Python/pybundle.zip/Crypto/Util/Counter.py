# Counter factory for CTR mode, API-compatible subset of
# PyCryptodome's Crypto.Util.Counter.


class _Counter:
    def __init__(self, nbits, prefix, suffix, initial_value, little_endian):
        self._width = nbits // 8
        self._prefix = prefix
        self._suffix = suffix
        self._value = initial_value
        self._little_endian = little_endian

    def __call__(self):
        order = "little" if self._little_endian else "big"
        block = (self._prefix
                 + self._value.to_bytes(self._width, order)
                 + self._suffix)
        self._value += 1
        return block


def new(nbits, prefix=b"", suffix=b"", initial_value=1,
        little_endian=False, allow_wraparound=False):
    return _Counter(nbits, prefix, suffix, initial_value, little_endian)
