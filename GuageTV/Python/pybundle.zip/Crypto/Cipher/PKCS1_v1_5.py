# Pure-Python RSAES-PKCS1-v1_5 (EME-PKCS1-v1_5), API-compatible with
# the subset of PyCryptodome's Crypto.Cipher.PKCS1_v1_5 that TVBox
# spiders use: new(key).encrypt(msg) / .decrypt(ct, sentinel).

import os

try:
    from Crypto.Random import get_random_bytes as _rand_bytes
except Exception:  # pragma: no cover
    def _rand_bytes(n):
        return os.urandom(n)


class PKCS1_v1_5_Cipher:
    def __init__(self, key, randfunc=None):
        self._key = key
        self._randfunc = randfunc or _rand_bytes

    def can_encrypt(self):
        return True

    def can_decrypt(self):
        return self._key.has_private()

    def encrypt(self, message):
        k = self._key.size_in_bytes()
        if len(message) > k - 11:
            raise ValueError("Plaintext is too long.")
        ps_len = k - len(message) - 3
        ps = bytearray()
        while len(ps) < ps_len:
            chunk = self._randfunc(ps_len - len(ps))
            ps.extend(b for b in chunk if b != 0)
        em = b"\x00\x02" + bytes(ps[:ps_len]) + b"\x00" + bytes(message)
        m = int.from_bytes(em, "big")
        c = self._key._encrypt(m)
        return c.to_bytes(k, "big")

    def decrypt(self, ciphertext, sentinel, expected_pt_len=None):
        k = self._key.size_in_bytes()
        if len(ciphertext) != k:
            return sentinel
        c = int.from_bytes(ciphertext, "big")
        if c >= self._key.n:
            return sentinel
        try:
            m = self._key._decrypt(c)
        except Exception:
            return sentinel
        em = m.to_bytes(k, "big")
        if len(em) < 11 or em[0] != 0x00 or em[1] != 0x02:
            return sentinel
        sep = em.find(b"\x00", 2)
        if sep < 10:  # PS must be at least 8 nonzero bytes
            return sentinel
        plaintext = em[sep + 1:]
        if expected_pt_len is not None and len(plaintext) != expected_pt_len:
            return sentinel
        return plaintext


def new(key, randfunc=None):
    return PKCS1_v1_5_Cipher(key, randfunc)
