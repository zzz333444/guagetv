# Pure-Python AES (FIPS-197) + block modes, API-compatible with the
# subset of PyCryptodome that TVBox spiders actually use:
#   AES.new(key, AES.MODE_ECB|MODE_CBC|MODE_CTR|MODE_CFB|MODE_OFB, ...)
# Tables are generated from GF(2^8) arithmetic at import time instead of
# being hand-typed, and the implementation is verified against the NIST
# known-answer vectors in the project notes. Speed is fine for the small
# API payloads spiders decrypt; it is NOT a general crypto library.

# Mode constants (same values as PyCryptodome)
MODE_ECB = 1
MODE_CBC = 2
MODE_CFB = 3
MODE_OFB = 5
MODE_CTR = 6
MODE_CCM = 10
MODE_GCM = 11

block_size = 16
key_size = (16, 24, 32)


def _gmul(a, b):
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        hi = a & 0x80
        a = (a << 1) & 0xFF
        if hi:
            a ^= 0x1B
        b >>= 1
    return p


def _build_tables():
    sbox = [0] * 256
    inv_sbox = [0] * 256
    # multiplicative inverse via exponentiation, then affine transform
    def gf_pow(a, e):
        r = 1
        while e:
            if e & 1:
                r = _gmul(r, a)
            a = _gmul(a, a)
            e >>= 1
        return r

    for i in range(256):
        inv = 0 if i == 0 else gf_pow(i, 254)
        s = inv
        for shift in (1, 2, 3, 4):
            s ^= ((inv << shift) | (inv >> (8 - shift))) & 0xFF
        s = (s ^ 0x63) & 0xFF
        sbox[i] = s
        inv_sbox[s] = i
    return sbox, inv_sbox


_SBOX, _INV_SBOX = _build_tables()
_RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36]


def _expand_key(key):
    nk = len(key) // 4
    nr = nk + 6
    w = [list(key[4 * i:4 * i + 4]) for i in range(nk)]
    for i in range(nk, 4 * (nr + 1)):
        temp = list(w[i - 1])
        if i % nk == 0:
            temp = temp[1:] + temp[:1]
            temp = [_SBOX[b] for b in temp]
            temp[0] ^= _RCON[i // nk - 1]
        elif nk > 6 and i % nk == 4:
            temp = [_SBOX[b] for b in temp]
        w.append([w[i - nk][j] ^ temp[j] for j in range(4)])
    round_keys = []
    for r in range(nr + 1):
        rk = []
        for word in w[4 * r:4 * r + 4]:
            rk.extend(word)
        round_keys.append(rk)
    return round_keys, nr


def _add_rk(state, rk):
    return [b ^ k for b, k in zip(state, rk)]


def _shift_rows(s):
    # state is column-major: index = row + 4*col
    out = [0] * 16
    for r in range(4):
        for c in range(4):
            out[r + 4 * c] = s[r + 4 * ((c + r) % 4)]
    return out


def _inv_shift_rows(s):
    out = [0] * 16
    for r in range(4):
        for c in range(4):
            out[r + 4 * c] = s[r + 4 * ((c - r) % 4)]
    return out


def _mix_columns(s):
    out = [0] * 16
    for c in range(4):
        col = s[4 * c:4 * c + 4]
        out[4 * c + 0] = _gmul(col[0], 2) ^ _gmul(col[1], 3) ^ col[2] ^ col[3]
        out[4 * c + 1] = col[0] ^ _gmul(col[1], 2) ^ _gmul(col[2], 3) ^ col[3]
        out[4 * c + 2] = col[0] ^ col[1] ^ _gmul(col[2], 2) ^ _gmul(col[3], 3)
        out[4 * c + 3] = _gmul(col[0], 3) ^ col[1] ^ col[2] ^ _gmul(col[3], 2)
    return out


def _inv_mix_columns(s):
    out = [0] * 16
    for c in range(4):
        col = s[4 * c:4 * c + 4]
        out[4 * c + 0] = _gmul(col[0], 14) ^ _gmul(col[1], 11) ^ _gmul(col[2], 13) ^ _gmul(col[3], 9)
        out[4 * c + 1] = _gmul(col[0], 9) ^ _gmul(col[1], 14) ^ _gmul(col[2], 11) ^ _gmul(col[3], 13)
        out[4 * c + 2] = _gmul(col[0], 13) ^ _gmul(col[1], 9) ^ _gmul(col[2], 14) ^ _gmul(col[3], 11)
        out[4 * c + 3] = _gmul(col[0], 11) ^ _gmul(col[1], 13) ^ _gmul(col[2], 9) ^ _gmul(col[3], 14)
    return out


class _AESCipher:
    def __init__(self, key, mode, iv=None, counter=None, segment_size=8):
        if len(key) not in key_size:
            raise ValueError("Incorrect AES key length")
        self.key = key
        self.mode = mode
        self.block_size = 16
        self.iv = iv
        self._rks, self._nr = _expand_key(key)
        self._counter = counter
        self._segment_size = segment_size
        self._prev = iv
        self._ofb_state = iv
        self._ctr_block = b""
        if mode == MODE_CTR and counter is None:
            raise ValueError("CTR mode requires a counter")

    # -- raw block ops ---------------------------------------------------
    def _encrypt_block(self, block):
        s = _add_rk(list(block), self._rks[0])
        for rnd in range(1, self._nr):
            s = [_SBOX[b] for b in s]
            s = _shift_rows(s)
            s = _mix_columns(s)
            s = _add_rk(s, self._rks[rnd])
        s = [_SBOX[b] for b in s]
        s = _shift_rows(s)
        s = _add_rk(s, self._rks[self._nr])
        return bytes(s)

    def _decrypt_block(self, block):
        s = _add_rk(list(block), self._rks[self._nr])
        for rnd in range(self._nr - 1, 0, -1):
            s = _inv_shift_rows(s)
            s = [_INV_SBOX[b] for b in s]
            s = _add_rk(s, self._rks[rnd])
            s = _inv_mix_columns(s)
        s = _inv_shift_rows(s)
        s = [_INV_SBOX[b] for b in s]
        s = _add_rk(s, self._rks[0])
        return bytes(s)

    # -- modes -------------------------------------------------------------
    def encrypt(self, data):
        if self.mode == MODE_ECB:
            self._require_blocks(data)
            return b"".join(self._encrypt_block(data[i:i + 16])
                            for i in range(0, len(data), 16))
        if self.mode == MODE_CBC:
            self._require_blocks(data)
            out = []
            prev = self._prev
            for i in range(0, len(data), 16):
                block = bytes(a ^ b for a, b in zip(data[i:i + 16], prev))
                prev = self._encrypt_block(block)
                out.append(prev)
            self._prev = prev
            return b"".join(out)
        if self.mode == MODE_CTR:
            return self._ctr_crypt(data)
        if self.mode == MODE_OFB:
            return self._ofb_crypt(data)
        if self.mode == MODE_CFB:
            return self._cfb_crypt(data, encrypting=True)
        raise ValueError("Unsupported mode")

    def decrypt(self, data):
        if self.mode == MODE_ECB:
            self._require_blocks(data)
            return b"".join(self._decrypt_block(data[i:i + 16])
                            for i in range(0, len(data), 16))
        if self.mode == MODE_CBC:
            self._require_blocks(data)
            out = []
            prev = self._prev
            for i in range(0, len(data), 16):
                chunk = data[i:i + 16]
                plain = self._decrypt_block(chunk)
                out.append(bytes(a ^ b for a, b in zip(plain, prev)))
                prev = chunk
            self._prev = prev
            return b"".join(out)
        if self.mode == MODE_CTR:
            return self._ctr_crypt(data)
        if self.mode == MODE_OFB:
            return self._ofb_crypt(data)
        if self.mode == MODE_CFB:
            return self._cfb_crypt(data, encrypting=False)
        raise ValueError("Unsupported mode")

    def _require_blocks(self, data):
        if len(data) % 16 != 0:
            raise ValueError("Data must be padded to a multiple of 16 bytes")

    def _ctr_crypt(self, data):
        out = bytearray()
        buf = bytearray(self._ctr_block)
        for byte in data:
            if not buf:
                buf = bytearray(self._encrypt_block(self._counter()))
            out.append(byte ^ buf.pop(0))
        self._ctr_block = bytes(buf)
        return bytes(out)

    def _ofb_crypt(self, data):
        out = bytearray()
        state = self._ofb_state
        offset = 16  # force generation on first byte
        keystream = b""
        for byte in data:
            if offset >= 16:
                state = self._encrypt_block(state)
                keystream = state
                offset = 0
            out.append(byte ^ keystream[offset])
            offset += 1
        self._ofb_state = state
        return bytes(out)

    def _cfb_crypt(self, data, encrypting):
        if self._segment_size != 8:
            raise ValueError("Only CFB8 is supported")
        out = bytearray()
        state = self._prev
        for byte in data:
            ks = self._encrypt_block(state)[0]
            result = byte ^ ks
            fed = result if encrypting else byte
            state = state[1:] + bytes([fed])
            out.append(result)
        self._prev = state
        return bytes(out)


def new(key, mode, *args, **kwargs):
    if mode in (MODE_GCM, MODE_CCM):
        raise NotImplementedError("GCM/CCM not available in the pure-Python shim")
    iv = kwargs.get("iv", kwargs.get("IV"))
    if args and iv is None:
        iv = args[0]
    counter = kwargs.get("counter")
    if mode == MODE_CTR and counter is None:
        nonce = kwargs.get("nonce", b"")
        initial = kwargs.get("initial_value", 0)
        prefix = nonce
        width = 16 - len(prefix)
        state = {"value": initial}

        def _counter_fn():
            block = prefix + state["value"].to_bytes(width, "big")
            state["value"] += 1
            return block

        counter = _counter_fn
    if mode in (MODE_CBC, MODE_CFB, MODE_OFB) and iv is None:
        raise ValueError("This mode requires an IV")
    return _AESCipher(key, mode, iv=iv, counter=counter,
                      segment_size=kwargs.get("segment_size", 8))
