# Pure-Python Triple-DES (EDE) + block modes, API-compatible with the
# subset of PyCryptodome that TVBox spiders actually use. Built on the
# DES shim's mode machinery; the interface mirrors the bundle's
# pure-Python AES/DES shims. 16-byte keys mean K3 == K1 (two-key EDE),
# 24-byte keys are three-key EDE, exactly like PyCryptodome.
#
# Note: like PyCryptodome, this shim does not reject degenerate keys
# (K1 == K2 collapses to single DES) — it just runs EDE.

from Crypto.Cipher.DES import (
    MODE_ECB, MODE_CBC, MODE_CFB, MODE_OFB, MODE_CTR, MODE_GCM,
    _BlockCipher, _des_block, _subkeys,
)

block_size = 8
key_size = (16, 24)


class _DES3Cipher(_BlockCipher):
    def __init__(self, key, mode, iv=None, counter=None, segment_size=8):
        if len(key) == 16:
            k1, k2, k3 = key[:8], key[8:16], key[:8]
        else:
            k1, k2, k3 = key[:8], key[8:16], key[16:24]
        self._subs1 = _subkeys(k1)
        self._subs2 = _subkeys(k2)
        self._subs3 = _subkeys(k3)
        super().__init__(key, mode, iv=iv, counter=counter,
                         segment_size=segment_size)

    def _encrypt_block(self, block):
        block = _des_block(block, self._subs1)
        block = _des_block(block, self._subs2, decrypt=True)
        return _des_block(block, self._subs3)

    def _decrypt_block(self, block):
        block = _des_block(block, self._subs3, decrypt=True)
        block = _des_block(block, self._subs2)
        return _des_block(block, self._subs1, decrypt=True)


def new(key, mode, *args, **kwargs):
    if len(key) not in key_size:
        raise ValueError("Incorrect DES3 key length")
    if mode == MODE_GCM:
        raise NotImplementedError("GCM is not a DES3 mode")
    iv = kwargs.get("iv", kwargs.get("IV"))
    if args and iv is None:
        iv = args[0]
    counter = kwargs.get("counter")
    if mode == MODE_CTR and counter is None:
        nonce = kwargs.get("nonce", b"")
        initial = kwargs.get("initial_value", 0)
        prefix = nonce
        width = 8 - len(prefix)
        state = {"value": initial}

        def _counter_fn():
            block = prefix + state["value"].to_bytes(width, "big")
            state["value"] += 1
            return block

        counter = _counter_fn
    if mode in (MODE_CBC, MODE_CFB, MODE_OFB) and iv is None:
        raise ValueError("This mode requires an IV")
    return _DES3Cipher(key, mode, iv=iv, counter=counter,
                       segment_size=kwargs.get("segment_size", 8))
