# Pure-Python DES (FIPS 46-3) + block modes, API-compatible with the
# subset of PyCryptodome that TVBox spiders actually use:
#   DES.new(key, DES.MODE_ECB|MODE_CBC|MODE_CTR|MODE_CFB|MODE_OFB, ...)
# The interface (new() signature, CTR counter built from nonce +
# initial_value, CFB segment_size) mirrors the pure-Python AES shim
# already in the bundle. Speed is fine for the small API payloads
# spiders decrypt; it is NOT a general crypto library.

# Mode constants (same values as PyCryptodome)
MODE_ECB = 1
MODE_CBC = 2
MODE_CFB = 3
MODE_OFB = 5
MODE_CTR = 6
MODE_GCM = 11

block_size = 8
key_size = (8,)

_IP = (
    58, 50, 42, 34, 26, 18, 10, 2,
    60, 52, 44, 36, 28, 20, 12, 4,
    62, 54, 46, 38, 30, 22, 14, 6,
    64, 56, 48, 40, 32, 24, 16, 8,
    57, 49, 41, 33, 25, 17, 9, 1,
    59, 51, 43, 35, 27, 19, 11, 3,
    61, 53, 45, 37, 29, 21, 13, 5,
    63, 55, 47, 39, 31, 23, 15, 7,
)

_FP = (
    40, 8, 48, 16, 56, 24, 64, 32,
    39, 7, 47, 15, 55, 23, 63, 31,
    38, 6, 46, 14, 54, 22, 62, 30,
    37, 5, 45, 13, 53, 21, 61, 29,
    36, 4, 44, 12, 52, 20, 60, 28,
    35, 3, 43, 11, 51, 19, 59, 27,
    34, 2, 42, 10, 50, 18, 58, 26,
    33, 1, 41, 9, 49, 17, 57, 25,
)

_E = (
    32, 1, 2, 3, 4, 5,
    4, 5, 6, 7, 8, 9,
    8, 9, 10, 11, 12, 13,
    12, 13, 14, 15, 16, 17,
    16, 17, 18, 19, 20, 21,
    20, 21, 22, 23, 24, 25,
    24, 25, 26, 27, 28, 29,
    28, 29, 30, 31, 32, 1,
)

_P = (
    16, 7, 20, 21,
    29, 12, 28, 17,
    1, 15, 23, 26,
    5, 18, 31, 10,
    2, 8, 24, 14,
    32, 27, 3, 9,
    19, 13, 30, 6,
    22, 11, 4, 25,
)

_PC1 = (
    57, 49, 41, 33, 25, 17, 9,
    1, 58, 50, 42, 34, 26, 18,
    10, 2, 59, 51, 43, 35, 27,
    19, 11, 3, 60, 52, 44, 36,
    63, 55, 47, 39, 31, 23, 15,
    7, 62, 54, 46, 38, 30, 22,
    14, 6, 61, 53, 45, 37, 29,
    21, 13, 5, 28, 20, 12, 4,
)

_PC2 = (
    14, 17, 11, 24, 1, 5,
    3, 28, 15, 6, 21, 10,
    23, 19, 12, 4, 26, 8,
    16, 7, 27, 20, 13, 2,
    41, 52, 31, 37, 47, 55,
    30, 40, 51, 45, 33, 48,
    44, 49, 39, 56, 34, 53,
    46, 42, 50, 36, 29, 32,
)

_SHIFTS = (1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1)

_SBOX = (
    (  # S1
        14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7,
        0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8,
        4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0,
        15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13,
    ),
    (  # S2
        15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10,
        3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5,
        0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15,
        13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9,
    ),
    (  # S3
        10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8,
        13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1,
        13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7,
        1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12,
    ),
    (  # S4
        7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15,
        13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9,
        10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4,
        3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14,
    ),
    (  # S5
        2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9,
        14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6,
        4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14,
        11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3,
    ),
    (  # S6
        12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11,
        10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8,
        9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6,
        4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13,
    ),
    (  # S7
        4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1,
        13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6,
        1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2,
        6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12,
    ),
    (  # S8
        13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7,
        1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2,
        7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8,
        2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11,
    ),
)


def _permute(value, table, in_bits):
    out = 0
    for pos in table:
        out = (out << 1) | ((value >> (in_bits - pos)) & 1)
    return out


def _subkeys(key):
    """16 round subkeys (48-bit ints) for one 8-byte DES key."""
    k = _permute(int.from_bytes(key, "big"), _PC1, 64)
    c = (k >> 28) & 0x0FFFFFFF
    d = k & 0x0FFFFFFF
    subs = []
    for shift in _SHIFTS:
        c = ((c << shift) | (c >> (28 - shift))) & 0x0FFFFFFF
        d = ((d << shift) | (d >> (28 - shift))) & 0x0FFFFFFF
        subs.append(_permute((c << 28) | d, _PC2, 56))
    return subs


def _f(r, subkey):
    x = _permute(r, _E, 32) ^ subkey
    out = 0
    for i in range(8):
        six = (x >> (42 - 6 * i)) & 0x3F
        row = ((six & 0x20) >> 4) | (six & 0x01)
        col = (six >> 1) & 0x0F
        out = (out << 4) | _SBOX[i][row * 16 + col]
    return _permute(out, _P, 32)


def _des_block(block, subs, decrypt=False):
    v = _permute(int.from_bytes(block, "big"), _IP, 64)
    l = (v >> 32) & 0xFFFFFFFF
    r = v & 0xFFFFFFFF
    keys = reversed(subs) if decrypt else subs
    for sk in keys:
        l, r = r, l ^ _f(r, sk)
    pre = (r << 32) | l
    return _permute(pre, _FP, 64).to_bytes(8, "big")


class _BlockCipher:
    """Shared mode machinery (ECB/CBC/CFB/OFB/CTR) over a block op."""

    def __init__(self, key, mode, iv=None, counter=None, segment_size=8):
        self.key = key
        self.mode = mode
        self.block_size = 8
        self.iv = iv
        self._counter = counter
        self._segment_size = segment_size
        self._prev = iv
        self._ofb_state = iv
        self._ctr_block = b""

    def _encrypt_block(self, block):
        raise NotImplementedError

    def _decrypt_block(self, block):
        raise NotImplementedError

    def encrypt(self, data):
        if self.mode == MODE_ECB:
            self._require_blocks(data)
            return b"".join(self._encrypt_block(data[i:i + 8])
                            for i in range(0, len(data), 8))
        if self.mode == MODE_CBC:
            self._require_blocks(data)
            out = []
            prev = self._prev
            for i in range(0, len(data), 8):
                block = bytes(a ^ b for a, b in zip(data[i:i + 8], prev))
                prev = self._encrypt_block(block)
                out.append(prev)
            self._prev = prev
            return b"".join(out)
        if self.mode == MODE_CTR:
            return self._ctr_crypt(data)
        if self.mode == MODE_OFB:
            return self._ofb_crypt(data)
        if self.mode == MODE_CFB:
            return self._cfb_crypt(data, encrypting=True)
        raise ValueError("Unsupported mode")

    def decrypt(self, data):
        if self.mode == MODE_ECB:
            self._require_blocks(data)
            return b"".join(self._decrypt_block(data[i:i + 8])
                            for i in range(0, len(data), 8))
        if self.mode == MODE_CBC:
            self._require_blocks(data)
            out = []
            prev = self._prev
            for i in range(0, len(data), 8):
                chunk = data[i:i + 8]
                plain = self._decrypt_block(chunk)
                out.append(bytes(a ^ b for a, b in zip(plain, prev)))
                prev = chunk
            self._prev = prev
            return b"".join(out)
        if self.mode == MODE_CTR:
            return self._ctr_crypt(data)
        if self.mode == MODE_OFB:
            return self._ofb_crypt(data)
        if self.mode == MODE_CFB:
            return self._cfb_crypt(data, encrypting=False)
        raise ValueError("Unsupported mode")

    def _require_blocks(self, data):
        if len(data) % 8 != 0:
            raise ValueError("Data must be padded to a multiple of 8 bytes")

    def _ctr_crypt(self, data):
        out = bytearray()
        buf = bytearray(self._ctr_block)
        for byte in data:
            if not buf:
                buf = bytearray(self._encrypt_block(self._counter()))
            out.append(byte ^ buf.pop(0))
        self._ctr_block = bytes(buf)
        return bytes(out)

    def _ofb_crypt(self, data):
        out = bytearray()
        state = self._ofb_state
        offset = 8  # force generation on first byte
        keystream = b""
        for byte in data:
            if offset >= 8:
                state = self._encrypt_block(state)
                keystream = state
                offset = 0
            out.append(byte ^ keystream[offset])
            offset += 1
        self._ofb_state = state
        return bytes(out)

    def _cfb_crypt(self, data, encrypting):
        # segment_size >= the block size in bits means full-block
        # feedback (CFB64 here; code ported from AES spiders passes
        # segment_size=128, which means the same thing for DES).
        if self._segment_size >= 64:
            return self._cfb_full_crypt(data, encrypting)
        if self._segment_size != 8:
            raise ValueError("Only CFB8 and full-block CFB are supported")
        out = bytearray()
        state = self._prev
        for byte in data:
            ks = self._encrypt_block(state)[0]
            result = byte ^ ks
            fed = result if encrypting else byte
            state = state[1:] + bytes([fed])
            out.append(result)
        self._prev = state
        return bytes(out)

    def _cfb_full_crypt(self, data, encrypting):
        # CFB with a segment the size of the block (what PyCryptodome
        # calls segment_size=128 for AES; for DES the feedback register
        # is the full 8-byte block).
        out = bytearray()
        state = self._prev
        for i in range(0, len(data), 8):
            chunk = data[i:i + 8]
            ks = self._encrypt_block(state)
            result = bytes(a ^ b for a, b in zip(chunk, ks))
            fed = result if encrypting else chunk
            state = (state + fed)[len(fed):]
            out += result
        self._prev = state
        return bytes(out)


class _DESCipher(_BlockCipher):
    def __init__(self, key, mode, iv=None, counter=None, segment_size=8):
        self._subs = _subkeys(key)
        super().__init__(key, mode, iv=iv, counter=counter,
                         segment_size=segment_size)

    def _encrypt_block(self, block):
        return _des_block(block, self._subs)

    def _decrypt_block(self, block):
        return _des_block(block, self._subs, decrypt=True)


def new(key, mode, *args, **kwargs):
    if len(key) not in key_size:
        raise ValueError("Incorrect DES key length")
    if mode == MODE_GCM:
        raise NotImplementedError("GCM is not a DES mode")
    iv = kwargs.get("iv", kwargs.get("IV"))
    if args and iv is None:
        iv = args[0]
    counter = kwargs.get("counter")
    if mode == MODE_CTR and counter is None:
        nonce = kwargs.get("nonce", b"")
        initial = kwargs.get("initial_value", 0)
        prefix = nonce
        width = 8 - len(prefix)
        state = {"value": initial}

        def _counter_fn():
            block = prefix + state["value"].to_bytes(width, "big")
            state["value"] += 1
            return block

        counter = _counter_fn
    if mode in (MODE_CBC, MODE_CFB, MODE_OFB) and iv is None:
        raise ValueError("This mode requires an IV")
    return _DESCipher(key, mode, iv=iv, counter=counter,
                      segment_size=kwargs.get("segment_size", 8))
