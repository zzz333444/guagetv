# RC4 (ARC4), API-compatible subset of PyCryptodome's Crypto.Cipher.ARC4.

class ARC4Cipher:
    def __init__(self, key, drop=768):
        if not (1 <= len(key) <= 256):
            raise ValueError("Incorrect ARC4 key length")
        s = list(range(256))
        j = 0
        for i in range(256):
            j = (j + s[i] + key[i % len(key)]) & 0xFF
            s[i], s[j] = s[j], s[i]
        self._s = s
        self._i = 0
        self._j = 0
        if drop:
            self.encrypt(bytes(drop))

    def _keystream_byte(self):
        s = self._s
        self._i = (self._i + 1) & 0xFF
        self._j = (self._j + s[self._i]) & 0xFF
        s[self._i], s[self._j] = s[self._j], s[self._i]
        return s[(s[self._i] + s[self._j]) & 0xFF]

    def encrypt(self, data):
        return bytes(b ^ self._keystream_byte() for b in data)

    decrypt = encrypt


def new(key, *args, **kwargs):
    return ARC4Cipher(key, drop=kwargs.get("drop", 768))
