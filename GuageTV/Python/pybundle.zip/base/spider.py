# -*- coding: utf-8 -*-
"""CatVod-compatible base Spider for 呱壳's embedded Python runtime.

TVBox py spiders do `from base.spider import Spider` and rely on the
host for HTTP (self.fetch / self.post). On FongMi/Android those go
through OkHttp; here they go through the vendored `requests` stack.
Only the widely used surface is implemented; anything missing raises
AttributeError inside the spider, which the runner reports verbatim —
an honest failure beats a silently wrong shim.
"""
import re

import requests


class Spider:
    def __init__(self):
        self._session = requests.Session()

    # -- identity / lifecycle -------------------------------------------
    def getName(self):
        return getattr(self, "name", "") or self.__class__.__name__

    def init(self, extend=""):
        pass

    def destroy(self):
        pass

    # -- content protocol (overridden by real spiders) -------------------
    def homeContent(self, filter):
        return {"class": [], "list": []}

    def homeVideoContent(self):
        return {"list": []}

    def categoryContent(self, tid, pg, filter, extend):
        return {"list": [], "page": int(pg), "pagecount": 1, "limit": 20, "total": 0}

    def detailContent(self, ids):
        return {"list": []}

    def searchContent(self, key, quick, pg="1"):
        return {"list": []}

    def playerContent(self, flag, id, vipFlags):
        return {"parse": 0, "playUrl": "", "url": id}

    def liveContent(self, url):
        return ""

    # -- helpers spiders expect from the host ----------------------------
    def fetch(self, url, params=None, headers=None, cookies=None,
              timeout=15, verify=True, **kwargs):
        return self._session.get(url, params=params, headers=headers,
                                 cookies=cookies, timeout=timeout,
                                 verify=verify, **kwargs)

    def post(self, url, data=None, json=None, params=None, headers=None,
             cookies=None, timeout=15, verify=True, **kwargs):
        return self._session.post(url, data=data, json=json, params=params,
                                  headers=headers, cookies=cookies,
                                  timeout=timeout, verify=verify, **kwargs)

    def isVideoFormat(self, url):
        return bool(re.search(
            r"\.(m3u8|mp4|mkv|flv|ts|mpd|avi|mov|webm)(\?|$)", url or "", re.I))

    def manualVideoCheck(self):
        return False

    def getProxyUrl(self):
        return ""

    def log(self, message):
        print(message)
