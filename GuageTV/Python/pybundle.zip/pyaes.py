# pyaes subset shim built on the bundle's own AES core.
# Spiders use pyaes for CBC/ECB payload decryption:
#   pyaes.AESModeOfOperationCBC(key, iv=iv).decrypt(data)
#   pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, iv), ...).feed(...)
from Crypto.Cipher import AES as _AES


def _chunks(data, size=16):
    for i in range(0, len(data), size):
        yield data[i:i + size]


class _ModeBase:
    mode = None

    def __init__(self, key, iv=None):
        self._key = key
        self._iv = iv

    def _cipher(self):
        if self.mode == _AES.MODE_CBC:
            return _AES.new(self._key, _AES.MODE_CBC, self._iv)
        if self.mode == _AES.MODE_ECB:
            return _AES.new(self._key, _AES.MODE_ECB)
        if self.mode == _AES.MODE_CTR:
            from Crypto.Util import Counter
            counter = Counter.new(128, initial_value=int.from_bytes(self._iv, "big"))
            return _AES.new(self._key, _AES.MODE_CTR, counter=counter)
        if self.mode == _AES.MODE_OFB:
            return _AES.new(self._key, _AES.MODE_OFB, self._iv)
        if self.mode == _AES.MODE_CFB:
            return _AES.new(self._key, _AES.MODE_CFB, self._iv, segment_size=128)
        raise ValueError("unsupported mode")

    def encrypt(self, data):
        return self._cipher().encrypt(bytes(data))

    def decrypt(self, data):
        return self._cipher().decrypt(bytes(data))


class AESModeOfOperationECB(_ModeBase):
    mode = _AES.MODE_ECB

    def __init__(self, key):
        super().__init__(key)


class AESModeOfOperationCBC(_ModeBase):
    mode = _AES.MODE_CBC

    def __init__(self, key, iv=None):
        super().__init__(key, iv or b"\x00" * 16)


class AESModeOfOperationCTR(_ModeBase):
    mode = _AES.MODE_CTR

    def __init__(self, key, iv=None, counter=None):
        iv = iv
        if iv is None and counter is not None:
            initial = getattr(counter, "_initial_value", None)
            if initial is not None:
                iv = initial.to_bytes(16, "big")
        super().__init__(key, iv or b"\x00" * 16)


class AESModeOfOperationOFB(_ModeBase):
    mode = _AES.MODE_OFB

    def __init__(self, key, iv=None):
        super().__init__(key, iv or b"\x00" * 16)


class AESModeOfOperationCFB(_ModeBase):
    mode = _AES.MODE_CFB

    def __init__(self, key, iv=None, segment_size=128):
        super().__init__(key, iv or b"\x00" * 16)


class _Feeder:
    def __init__(self, mode, padding=None):
        self._cipher = mode._cipher()
        self._buffer = b""
        self._padding = padding

    def feed(self, data=None):
        if data:
            self._buffer += bytes(data)
        whole = len(self._buffer) - (len(self._buffer) % 16)
        if whole == 0:
            return b""
        chunk, self._buffer = self._buffer[:whole], self._buffer[whole:]
        return self._process(chunk)

    def finish(self):
        tail, self._buffer = self._buffer, b""
        if not tail:
            return b""
        if self._padding == "pkcs7" and isinstance(self, Decrypter):
            tail = tail + b"\x00" * (16 - len(tail))
        return self._process(tail)


class Encrypter(_Feeder):
    def _process(self, chunk):
        return self._cipher.encrypt(chunk)


class Decrypter(_Feeder):
    def _process(self, chunk):
        return self._cipher.decrypt(chunk)


AESEncrypter = Encrypter
AESDecrypter = Decrypter
