# cachetools subset shim — the pieces spiders actually use:
# LRUCache / TTLCache as dict-like caches, hashkey, and the
# @cached / @ttl_cached decorators. Semantics follow upstream
# closely enough for request-result caching inside a spider.
import time
from collections import OrderedDict
from functools import wraps


def hashkey(*args, **kwargs):
    if kwargs:
        return args + (object.__hash__,) + tuple(sorted(kwargs.items()))
    return args


class LRUCache(dict):
    def __init__(self, maxsize=128, **kwargs):
        super().__init__()
        self.maxsize = maxsize
        self._order = OrderedDict()

    def __getitem__(self, key):
        value = super().__getitem__(key)
        self._order.move_to_end(key)
        return value

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        self._order[key] = None
        self._order.move_to_end(key)
        while self.maxsize and len(self) > self.maxsize:
            oldest, _ = self._order.popitem(last=False)
            super().__delitem__(oldest)

    def __delitem__(self, key):
        super().__delitem__(key)
        self._order.pop(key, None)

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default

    def pop(self, key, *args):
        self._order.pop(key, None)
        return super().pop(key, *args)

    def clear(self):
        super().clear()
        self._order.clear()


class TTLCache(LRUCache):
    def __init__(self, maxsize=128, ttl=600, **kwargs):
        super().__init__(maxsize)
        self.ttl = ttl
        self._expires = {}

    def _expired(self, key):
        deadline = self._expires.get(key)
        return deadline is not None and deadline <= time.monotonic()

    def __getitem__(self, key):
        if self._expired(key):
            self.pop(key, None)
            raise KeyError(key)
        return super().__getitem__(key)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        self._expires[key] = time.monotonic() + self.ttl

    def __contains__(self, key):
        return not self._expired(key) and super().__contains__(key)

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default

    def pop(self, key, *args):
        self._expires.pop(key, None)
        return super().pop(key, *args)

    def clear(self):
        super().clear()
        self._expires.clear()


class cached:
    def __init__(self, cache, key=hashkey):
        self.cache = cache
        self.key = key

    def __call__(self, func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            k = self.key(*args, **kwargs)
            try:
                return self.cache[k]
            except KeyError:
                pass
            result = func(*args, **kwargs)
            try:
                self.cache[k] = result
            except ValueError:
                pass
            return result
        wrapper.cache = self.cache
        return wrapper


class ttl_cached:
    def __init__(self, maxsize=128, ttl=600, typed=False):
        self.cache = TTLCache(maxsize=maxsize, ttl=ttl)

    def __call__(self, func):
        return cached(self.cache)(func)


def cachedmethod(key=hashkey):
    def decorator(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            cache = getattr(self, "_cachetools_cache", None)
            if cache is None:
                cache = self._cachetools_cache = LRUCache(maxsize=1024)
            k = key(*args, **kwargs)
            try:
                return cache[k]
            except KeyError:
                pass
            result = func(self, *args, **kwargs)
            cache[k] = result
            return result
        return wrapper
    return decorator
