# -*- coding: utf-8 -*-
"""Pure-Python subset of ``lxml.etree`` for the GuageTV pybundle.

The bundle's Python has no C extensions, so spiders that start with
``from lxml import etree`` and drive ``etree.HTML(html).xpath(...)``
need a stand-in.  This module implements, on a small DOM built with
the standard library's ``html.parser``:

* ``Element`` / ``SubElement`` with tag / attrib / text / tail,
  append/insert/remove, get/set, find/findall/findtext over the
  ElementPath subset (``tag``, ``*``, ``.//tag``, ``a/b`` chains),
  ``iter()``, ``getchildren()``, iteration and ``len()``.
* ``HTML()`` / ``fromstring()`` / ``XML()`` / ``parse()`` — lenient
  HTML parsing; fragments are wrapped in ``html > body`` exactly
  like libxml2 does, and empty input yields ``None`` from HTML().
* ``xpath()`` over the subset spiders actually use: ``//tag``,
  ``//*``, ``//tag[@a='v']``, ``[@a]``, ``[contains(@a,'v')]``,
  ``[contains(text(),'v')]``, ``[contains(.,'v')]``, ``[text()='v']``,
  ``and``-combined predicates, stacked predicates, positional
  predicates ``[n]`` / ``[last()]`` with true XPath per-parent
  semantics, path chains ``//a/b/c``, trailing ``/text()`` and
  ``/@attr``, relative ``.//`` starts.
* ``tostring()`` with lxml's byte conventions (default = ASCII
  bytes with numeric character references, ``encoding='unicode'``
  returns str).

Deviations from real lxml, by design: the parser never raises on
malformed HTML (it always recovers), ``fromstring`` is lenient
like ``HTML``, and unsupported XPath constructs raise
``XPathError`` instead of silently returning wrong results.
"""

import re
from html.parser import HTMLParser

__all__ = [
    "Element", "SubElement", "HTML", "XML", "fromstring", "tostring",
    "parse", "HTMLParser", "XMLParser", "XPathError",
]


class XPathError(Exception):
    pass


# ---------------------------------------------------------------------------
# Element
# ---------------------------------------------------------------------------

class Element:
    """A minimal stand-in for lxml's _Element."""

    def __init__(self, tag, attrib=None, **extra):
        self.tag = tag
        self.attrib = dict(attrib) if attrib else {}
        if extra:
            self.attrib.update(extra)
        self.text = None
        self.tail = None
        self._children = []
        self._parent = None

    # -- tree mutation ------------------------------------------------
    def append(self, child):
        if child._parent is not None:
            child._parent._children.remove(child)
        child._parent = self
        self._children.append(child)

    def insert(self, index, child):
        if child._parent is not None:
            child._parent._children.remove(child)
        child._parent = self
        self._children.insert(index, child)

    def remove(self, child):
        self._children.remove(child)
        child._parent = None

    def extend(self, children):
        for child in children:
            self.append(child)

    # -- attributes ----------------------------------------------------
    def get(self, key, default=None):
        return self.attrib.get(key, default)

    def set(self, key, value):
        self.attrib[key] = value

    def keys(self):
        return self.attrib.keys()

    def items(self):
        return self.attrib.items()

    # -- navigation ----------------------------------------------------
    def getparent(self):
        return self._parent

    def getchildren(self):
        return list(self._children)

    def __iter__(self):
        return iter(self._children)

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __repr__(self):
        return "<Element %s at 0x%x>" % (self.tag, id(self))

    def iter(self, tag=None):
        if tag is None or tag == "*" or self.tag == tag:
            yield self
        for child in self._children:
            yield from child.iter(tag)

    def itertext(self):
        if self.text:
            yield self.text
        for child in self._children:
            yield from child.itertext()
            if child.tail:
                yield child.tail

    def text_content(self):
        return "".join(self.itertext())

    # -- ElementPath subset ---------------------------------------------
    def find(self, path):
        found = self.findall(path)
        return found[0] if found else None

    def findall(self, path):
        return _findall(self, path)

    def findtext(self, path, default=None):
        el = self.find(path)
        if el is None:
            return default
        return el.text if el.text is not None else default

    # -- XPath subset ------------------------------------------------------
    def xpath(self, expr, **_kwargs):
        return _xpath(self, expr)


def SubElement(parent, tag, attrib=None, **extra):
    el = Element(tag, attrib, **extra)
    parent.append(el)
    return el


def _root_of(el):
    node = el
    while node._parent is not None:
        node = node._parent
    return node


def _desc_or_self(el):
    yield el
    for child in el._children:
        yield from _desc_or_self(child)


# ---------------------------------------------------------------------------
# Parsing (html.parser based, libxml2-flavoured recovery)
# ---------------------------------------------------------------------------

_VOID = frozenset(
    "area base br col embed hr img input link meta param source track wbr".split()
)

# start-tag -> set of currently-open tags it implicitly closes
_CLOSES = {
    "li": {"li"},
    "dt": {"dt", "dd"},
    "dd": {"dt", "dd"},
    "tr": {"tr", "td", "th"},
    "td": {"td", "th"},
    "th": {"td", "th"},
    "option": {"option"},
    "body": {"head"},
    "tbody": {"thead"},
    "tfoot": {"thead", "tbody"},
}
_P_CLOSERS = frozenset(
    "address article aside blockquote div dl fieldset figure footer form "
    "h1 h2 h3 h4 h5 h6 header hr main nav ol p pre section table ul".split()
)


class _TreeBuilder(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Element("#document")
        self._stack = [self.root]

    def _implied_close(self, tag):
        closes = set(_CLOSES.get(tag, ()))
        if tag in _P_CLOSERS:
            closes.add("p")
        while len(self._stack) > 1 and self._stack[-1].tag in closes:
            self._stack.pop()

    def _add(self, tag, attrs, push):
        self._implied_close(tag)
        el = Element(tag, {k: ("" if v is None else v) for k, v in attrs})
        self._stack[-1].append(el)
        if push and tag not in _VOID:
            self._stack.append(el)

    def handle_starttag(self, tag, attrs):
        self._add(tag, attrs, push=True)

    def handle_startendtag(self, tag, attrs):
        self._add(tag, attrs, push=False)

    def handle_endtag(self, tag):
        for i in range(len(self._stack) - 1, 0, -1):
            if self._stack[i].tag == tag:
                del self._stack[i:]
                return
        # unmatched end tag: ignore, like a recovering parser

    def handle_data(self, data):
        if not data:
            return
        current = self._stack[-1]
        if current._children:
            last = current._children[-1]
            last.tail = (last.tail or "") + data
        else:
            current.text = (current.text or "") + data


def _decode(text):
    if isinstance(text, (bytes, bytearray)):
        raw = bytes(text)
        charset = None
        m = re.search(rb"charset\s*=\s*[\"']?([\w-]+)", raw[:4096], re.I)
        if m:
            charset = m.group(1).decode("ascii", "replace").lower()
            if charset in ("gb2312", "gb_2312-80"):
                charset = "gbk"
        for enc in (charset, "utf-8"):
            if not enc:
                continue
            try:
                return raw.decode(enc)
            except (UnicodeDecodeError, LookupError):
                continue
        return raw.decode("utf-8", "replace")
    return text


def _parse_raw(text):
    """Parse into a synthetic root whose children are the top-level
    nodes of the input (no html/body implication yet)."""
    builder = _TreeBuilder()
    builder.feed(_decode(text))
    builder.close()
    return builder.root


def _wrap_document(raw):
    """libxml2-style document: an existing lone <html> wins, other
    content is wrapped into html > body."""
    kids = list(raw._children)
    if len(kids) == 1 and kids[0].tag == "html":
        html_el = kids[0]
        html_el._parent = None
        return html_el
    html_el = Element("html")
    body = SubElement(html_el, "body")
    if raw.text:
        body.text = raw.text
    for child in kids:
        body.append(child)
    return html_el


def HTML(text, **_kwargs):
    """Parse HTML, returning the root <html> element (None for
    empty input), mirroring lxml.etree.HTML."""
    if text is None:
        raise TypeError("HTML() argument must be a string or bytes")
    if isinstance(text, (bytes, bytearray)):
        if not bytes(text).strip():
            return None
    elif not str(text).strip():
        return None
    return _wrap_document(_parse_raw(text))


def fromstring(text, parser=None, **_kwargs):
    """Lenient like HTML() in this shim (real lxml's default XML
    parser would reject most HTML; spiders pass HTML content or an
    HTMLParser, both of which mean 'recover like HTML')."""
    if text is None:
        raise TypeError("fromstring() argument must be a string or bytes")
    if isinstance(text, (bytes, bytearray)):
        if not bytes(text).strip():
            return None
    elif not str(text).strip():
        return None
    return _wrap_document(_parse_raw(text))


def XML(text, parser=None, **_kwargs):
    return fromstring(text, parser=parser)


class _ElementTree:
    def __init__(self, root):
        self._root = root

    def getroot(self):
        return self._root

    def xpath(self, expr, **kwargs):
        return self._root.xpath(expr, **kwargs)


def parse(source, parser=None, **_kwargs):
    if hasattr(source, "read"):
        data = source.read()
    else:
        with open(source, "rb") as fh:
            data = fh.read()
    return _ElementTree(fromstring(data, parser=parser))


class HTMLParser:
    """Placeholder for lxml's parser classes: accepted anywhere a
    spider passes a parser, behaviour is always the lenient HTML
    recovery above."""

    def __init__(self, *args, **kwargs):
        pass


class XMLParser:
    def __init__(self, *args, **kwargs):
        pass


# ---------------------------------------------------------------------------
# Serialisation
# ---------------------------------------------------------------------------

def _esc_text(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _esc_attr(s):
    return _esc_text(str(s)).replace('"', "&quot;")


def _serialise(el, method, out):
    out.append("<")
    out.append(el.tag)
    for key, value in el.attrib.items():
        out.append(' %s="%s"' % (key, _esc_attr(value)))
    has_content = bool(el._children) or bool(el.text)
    if el.tag in _VOID and not has_content:
        out.append(">" if method == "html" else "/>")
        return
    out.append(">")
    if el.text:
        out.append(_esc_text(el.text))
    for child in el._children:
        _serialise(child, method, out)
        if child.tail:
            out.append(_esc_text(child.tail))
    out.append("</%s>" % el.tag)


def tostring(el, encoding=None, method="xml", pretty_print=False,
             with_tail=True, **_kwargs):
    """Serialise a subtree (including the element's tail, as lxml
    does by default).  encoding='unicode' -> str; encoding None ->
    ASCII bytes with numeric character references (lxml's
    default); any other encoding name -> bytes in that encoding."""
    if el is None or not isinstance(el, Element):
        raise TypeError("tostring() requires an Element")
    parts = []
    _serialise(el, method, parts)
    if with_tail and el.tail:
        parts.append(_esc_text(el.tail))
    text = "".join(parts)
    if encoding == "unicode":
        return text
    enc = encoding or "ascii"
    if enc == "ascii":
        return text.encode("ascii", "xmlcharrefreplace")
    return text.encode(enc)


# ---------------------------------------------------------------------------
# ElementPath subset for find/findall
# ---------------------------------------------------------------------------

def _split_path(path):
    """Split an ElementPath/XPath-ish path into (axis, step) pairs,
    axis in {'child', 'desc'}; '/' inside [] is protected."""
    steps = []
    axis = "child"
    buf = []
    depth = 0
    quote = None
    i = 0
    s = path
    while i < len(s):
        ch = s[i]
        if quote:
            buf.append(ch)
            if ch == quote:
                quote = None
        elif ch in "\"'":
            quote = ch
            buf.append(ch)
        elif ch == "[":
            depth += 1
            buf.append(ch)
        elif ch == "]":
            depth -= 1
            buf.append(ch)
        elif ch == "/" and depth == 0:
            step = "".join(buf).strip()
            if step:
                steps.append((axis, step))
            buf = []
            if i + 1 < len(s) and s[i + 1] == "/":
                axis = "desc"
                i += 1
            else:
                axis = "child"
        else:
            buf.append(ch)
        i += 1
    step = "".join(buf).strip()
    if step:
        steps.append((axis, step))
    return steps


def _findall(context, path):
    if path in (".", ""):
        return [context]
    s = path.strip()
    base = context
    if s.startswith(".//"):
        first_axis, s = "desc", s[3:]
    elif s.startswith("./"):
        first_axis, s = "child", s[2:]
    elif s.startswith("//"):
        base, first_axis, s = _root_of(context), "desc", s[2:]
    elif s.startswith("/"):
        base, first_axis, s = _root_of(context), "child", s[1:]
    else:
        first_axis = "child"
    steps = _split_path(s)
    if steps:
        steps[0] = (first_axis, steps[0][1])
    nodes = [base]
    for axis, step in steps:
        if step == ".":
            continue
        if step == "..":
            nodes = [n._parent for n in nodes if n._parent is not None]
            continue
        out = []
        for ctx in nodes:
            if axis == "child":
                candidates = ctx._children
            else:
                candidates = []
                for node in _desc_or_self(ctx):
                    candidates.extend(node._children)
            for cand in candidates:
                if step == "*" or cand.tag == step:
                    if cand not in out:
                        out.append(cand)
        nodes = out
    return nodes


# ---------------------------------------------------------------------------
# XPath subset
# ---------------------------------------------------------------------------

def _parse_step(step):
    """'tag[pred][pred]' -> (nodetest, [predicate strings])."""
    start = step.find("[")
    if start == -1:
        return step.strip(), []
    nodetest = step[:start].strip()
    preds = []
    i = start
    while i < len(step):
        if step[i] != "[":
            raise XPathError("cannot parse step %r" % step)
        depth = 0
        quote = None
        j = i
        while j < len(step):
            ch = step[j]
            if quote:
                if ch == quote:
                    quote = None
            elif ch in "\"'":
                quote = ch
            elif ch == "[":
                depth += 1
            elif ch == "]":
                depth -= 1
                if depth == 0:
                    break
            j += 1
        if depth != 0:
            raise XPathError("unbalanced [ in step %r" % step)
        preds.append(step[i + 1:j].strip())
        i = j + 1
    return nodetest, preds


def _split_and(content):
    parts = []
    depth = 0
    quote = None
    buf = []
    i = 0
    while i < len(content):
        ch = content[i]
        if quote:
            buf.append(ch)
            if ch == quote:
                quote = None
            i += 1
            continue
        if ch in "\"'":
            quote = ch
            buf.append(ch)
            i += 1
            continue
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if depth == 0 and content.startswith(" and ", i):
            parts.append("".join(buf))
            buf = []
            i += 5
            continue
        buf.append(ch)
        i += 1
    parts.append("".join(buf))
    return [p.strip() for p in parts if p.strip()]


_Q = r"(?P<q>['\"])(?P<val>.*?)(?P=q)"
_COND_PATTERNS = [
    ("eq", re.compile(r"^@(?P<name>[\w:.-]+)\s*=\s*" + _Q + r"$", re.S)),
    ("contains_attr", re.compile(
        r"^contains\(\s*@(?P<name>[\w:.-]+)\s*,\s*" + _Q + r"\s*\)$", re.S)),
    ("contains_text", re.compile(
        r"^contains\(\s*text\(\)\s*,\s*" + _Q + r"\s*\)$", re.S)),
    ("contains_dot", re.compile(
        r"^contains\(\s*\.\s*,\s*" + _Q + r"\s*\)$", re.S)),
    ("eq_text", re.compile(r"^text\(\)\s*=\s*" + _Q + r"$", re.S)),
    ("exists", re.compile(r"^@(?P<name>[\w:.-]+)$")),
]


def _parse_condition(text):
    for kind, pattern in _COND_PATTERNS:
        m = pattern.match(text)
        if m:
            gd = m.groupdict()
            if kind in ("eq", "contains_attr"):
                return (kind, gd["name"], gd["val"])
            if kind in ("contains_text", "contains_dot", "eq_text"):
                return (kind, gd["val"])
            return (kind, gd["name"])
    raise XPathError("unsupported predicate %r" % text)


def _eval_condition(el, cond):
    kind = cond[0]
    if kind == "eq":
        return el.attrib.get(cond[1]) == cond[2]
    if kind == "exists":
        return cond[1] in el.attrib
    if kind == "contains_attr":
        return cond[2] in (el.attrib.get(cond[1]) or "")
    if kind == "contains_text":
        return cond[1] in (el.text or "")
    if kind == "contains_dot":
        return cond[1] in el.text_content()
    if kind == "eq_text":
        texts = [el.text] + [c.tail for c in el._children]
        return any(t == cond[1] for t in texts if t is not None)
    return False


def _apply_predicates(candidates, pred_texts):
    for pred in pred_texts:
        if re.fullmatch(r"\d+", pred):
            n = int(pred)
            candidates = [candidates[n - 1]] if 1 <= n <= len(candidates) else []
        elif pred == "last()":
            candidates = candidates[-1:]
        else:
            conds = [_parse_condition(p) for p in _split_and(pred)]
            candidates = [c for c in candidates
                          if all(_eval_condition(c, cond) for cond in conds)]
        if not candidates:
            break
    return candidates


def _text_nodes(el):
    out = []
    if el.text is not None:
        out.append(el.text)
    for child in el._children:
        if child.tail is not None:
            out.append(child.tail)
    return out


def _xpath(context, path):
    if not isinstance(path, str) or not path.strip():
        raise XPathError("empty XPath expression")
    s = path.strip()
    if s == ".":
        return [context]
    if s.startswith(".//"):
        base, first_axis, s = context, "desc", s[3:]
    elif s.startswith("//"):
        base, first_axis, s = _root_of(context), "desc", s[2:]
    elif s.startswith("./"):
        base, first_axis, s = context, "child", s[2:]
    elif s.startswith("/"):
        base, first_axis, s = _root_of(context), "child", s[1:]
    else:
        base, first_axis = context, "child"
    steps = _split_path(s)
    if steps:
        steps[0] = (first_axis, steps[0][1])
    nodes = [base]
    for index, (axis, step) in enumerate(steps):
        is_last = index == len(steps) - 1
        nodetest, preds = _parse_step(step)
        if "::" in nodetest:
            raise XPathError(
                "axis syntax %r is not supported by the shim" % nodetest)
        if nodetest == "text()":
            if not is_last:
                raise XPathError("text() is only supported as the final step")
            out = []
            for el in nodes:
                out.extend(_text_nodes(el))
            return out
        if nodetest.startswith("@"):
            if not is_last:
                raise XPathError("@attr is only supported as the final step")
            name = nodetest[1:]
            return [el.attrib[name] for el in nodes if name in el.attrib]
        if nodetest == ".":
            continue
        if nodetest == "..":
            nodes = [n._parent for n in nodes if n._parent is not None]
            continue
        out = []
        for ctx in nodes:
            if axis == "child":
                groups = [[c for c in ctx._children
                           if nodetest == "*" or c.tag == nodetest]]
            else:
                groups = [[c for c in node._children
                           if nodetest == "*" or c.tag == nodetest]
                          for node in _desc_or_self(ctx)]
            for group in groups:
                out.extend(_apply_predicates(group, preds))
        # descendant steps can revisit nodes when contexts nest
        seen = set()
        deduped = []
        for el in out:
            if id(el) not in seen:
                seen.add(id(el))
                deduped.append(el)
        nodes = deduped
    return nodes
