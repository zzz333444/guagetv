# -*- coding: utf-8 -*-
"""Pure-Python subset of ``lxml.html`` (see lxml/etree.py).

Mirrors the real fragment rules, verified against lxml 6.x:
``fromstring`` returns the lone top-level element itself for a
single-element fragment, wraps multi-element fragments in a
``<div>`` and text-only input in a ``<span>``; full documents come
back as the ``<html>`` root.  ``document_fromstring`` always
returns the full ``<html>`` document root.
"""

from ..etree import (
    Element, SubElement, HTMLParser, XMLParser, XPathError,
    _parse_raw, _wrap_document,
)
from .. import etree as _etree

__all__ = [
    "Element", "SubElement", "fromstring", "document_fromstring",
    "HTML", "tostring", "XPathError",
]


def _as_text(text):
    if isinstance(text, (bytes, bytearray)):
        return _etree._decode(bytes(text))
    return text


def fromstring(text, **_kwargs):
    if text is None:
        raise TypeError("fromstring() argument must be a string or bytes")
    decoded = _as_text(text)
    raw = _parse_raw(decoded)
    kids = list(raw._children)
    loose_text = bool(raw.text and raw.text.strip())
    if len(kids) == 1 and not loose_text:
        el = kids[0]
        el._parent = None
        raw._children = []
        return el
    if not kids:
        span = Element("span")
        span.text = raw.text
        return span
    div = Element("div")
    if raw.text:
        div.text = raw.text
    for child in kids:
        div.append(child)
    return div


def document_fromstring(text, **_kwargs):
    if text is None:
        raise TypeError("document_fromstring() argument must be a string or bytes")
    return _wrap_document(_parse_raw(_as_text(text)))


# Real lxml.html has its own HTML()/tostring(); spiders mostly use
# fromstring, but the aliases cost nothing.
HTML = _etree.HTML


def tostring(el, **kwargs):
    kwargs.setdefault("method", "html")
    return _etree.tostring(el, **kwargs)
