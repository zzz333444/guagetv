# Pure-Python lxml subset for the GuageTV pybundle (see etree.py).
# Real lxml exposes nothing much at package top level either; the
# useful surface lives in lxml.etree and lxml.html.
