# -*- coding: utf-8 -*-
"""In-app bridge module for 呱壳's embedded Python runtime.

Loaded once by Swift (PythonRuntime) from pybundle.zip. Contract:

    ping()                                -> version string (diagnostics)
    load_spider(path, extend_json)        -> JSON {"ok": true, "name": ...}
    call(method, args_json)               -> JSON {"ok": true, "result": ...}

Every failure is returned as {"ok": false, "error": <traceback>} so a
broken spider shows its own error in the UI instead of crashing the
shell. Spider instances are cached per file path; `call` always acts
on the most recently loaded spider.
"""
import importlib.util
import json
import os
import platform
import sys
import traceback

_spiders = {}
_active_path = None


def ping():
    return "Python " + platform.python_version()


def _to_jsonable(v):
    if isinstance(v, (dict, list, str, int, float, bool)) or v is None:
        return v
    return str(v)


def _normalise(ret):
    if ret is None:
        return {}
    if isinstance(ret, str):
        try:
            return json.loads(ret)
        except Exception:
            return {"result": ret}
    if isinstance(ret, dict):
        return {k: _to_jsonable(v) for k, v in ret.items()}
    return _to_jsonable(ret)


def load_spider(path, extend_json=""):
    global _active_path
    try:
        if path in _spiders:
            _active_path = path
            spider = _spiders[path]
            return json.dumps({"ok": True, "name": _spider_name(spider)},
                              ensure_ascii=False)
        spec = importlib.util.spec_from_file_location(
            "user_spider_" + str(len(_spiders)), path)
        mod = importlib.util.module_from_spec(spec)
        spider_dir = os.path.dirname(path)
        if spider_dir and spider_dir not in sys.path:
            sys.path.insert(0, spider_dir)
        spec.loader.exec_module(mod)
        cls = getattr(mod, "Spider", None)
        if cls is None:
            return json.dumps({"ok": False,
                               "error": "py 文件里没有定义 class Spider"},
                              ensure_ascii=False)
        spider = cls()
        init = getattr(spider, "init", None)
        if callable(init):
            try:
                init(extend_json or "")
            except TypeError:
                init()
        _spiders[path] = spider
        _active_path = path
        return json.dumps({"ok": True, "name": _spider_name(spider)},
                          ensure_ascii=False)
    except Exception:
        return json.dumps({"ok": False, "error": traceback.format_exc(limit=4)},
                          ensure_ascii=False)


def _spider_name(spider):
    try:
        return spider.getName()
    except Exception:
        return "Spider"


def call(method, args_json="{}"):
    try:
        spider = _spiders.get(_active_path)
        if spider is None:
            return json.dumps({"ok": False, "error": "尚未加载任何 Spider"},
                              ensure_ascii=False)
        args = json.loads(args_json or "{}")
        fn = getattr(spider, method, None)
        if fn is None:
            return json.dumps({"ok": False,
                               "error": "Spider 没有实现 " + method},
                              ensure_ascii=False)
        if method == "homeContent":
            ret = fn(bool(args.get("filter", False)))
        elif method == "homeVideoContent":
            ret = fn()
        elif method == "categoryContent":
            ret = fn(str(args.get("tid", "")), str(args.get("pg", "1")),
                     args.get("filter", {}), args.get("extend", {}))
        elif method == "detailContent":
            ret = fn(list(args.get("ids", [])))
        elif method == "searchContent":
            ret = fn(str(args.get("key", "")), bool(args.get("quick", False)),
                     str(args.get("pg", "1")))
        elif method == "playerContent":
            ret = fn(str(args.get("flag", "")), str(args.get("id", "")),
                     list(args.get("vipFlags", [])))
        elif method == "liveContent":
            ret = fn(str(args.get("url", "")))
        else:
            ret = fn()
        return json.dumps({"ok": True, "result": _normalise(ret)},
                          ensure_ascii=False, default=str)
    except Exception:
        return json.dumps({"ok": False, "error": traceback.format_exc(limit=4)},
                          ensure_ascii=False)
